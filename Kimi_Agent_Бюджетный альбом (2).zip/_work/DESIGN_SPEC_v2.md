# DESIGN SPEC v2 — Альбом отчетных форм (доработка)

Целевой файл: `/mnt/agents/output/Альбом_отчетных_форм_бюджетной_системы.xlsx` (пересборка, 43 вкладки).
Базовая визуальная система — без изменений (см. DESIGN_SPEC.md). Ниже только изменения и новые правила.
Существующие скрипты сборки: `/mnt/agents/output/_work/build/` (helpers.py, sheets_a/b/c.py, postprocess.py, build.py) — переиспользовать и доработать.

## 1. Состав и порядок вкладок (43)

1. `00_README` — обновить: новая структура (3 уровня + as-is блоки), 43 вкладки в навигации, примечание про DQ (технический фактор, не отображается).
2. `01_Report_Registry` — оглавление ВСЕХ форм с гиперссылками (см. п.2).
3–11. Отчетные формы в порядке R-01…R-09 с переименованными вкладками:
   `R-01_Budget_Control_Summary`, `R-02_Plan_Fact_Explorer`, `R-03_Variance_Waterfall`, `R-04_HC_Vacancy_Bridge`, `R-05_Compensation_Detail`, `R-06_АХР_Dashboard`, `R-07_Reconciliation`, `R-08_Data_Quality`, `R-09_Comments_Actions`.
   Уровни: R-01 = Стратегический; R-02, R-03, R-04, R-06 = Тактический; R-05, R-07, R-08, R-09 = Операционный. Уровень указывать в подзаголовке листа («Уровень: Тактический · аудитория: …»).
12–17. Спецификации: `11_Metric_Dictionary`, `12_Factor_Dictionary`, `13_Field_Dictionary`, `14_Access_Rights`, `15_UAT_Cases`, `16_Backlog_Roadmap` (имена вкладок сохранить).
18–27. Формы внесения данных (as-is): `IN_Salary charging`, `IN_Bonus charging`, `IN_Benefits`, `IN_Rates`, `IN_FX Rates`, `IN_Manual Adjustment`, `IN_Deferral`, `IN_Vacation Distr`, `IN_Vacancy`, `IN_Compensation`.
28–31. Формы загрузки факта (as-is): `FACT_МСФО Comp_Non Comp`, `FACT_Загрузка МСФО Банк`, `FACT_Загрузка поименная Банк`, `FACT_Страхование`.
32–39. HC Tracker (as-is): `HCT_Summary_MIR`, `HCT_Summary_GD`, `HCT_Summary_MIR_pools`, `HCT_Movement_ACT_MIR`, `HCT_Movement_ACT_weekly`, `HCT_Movement_TGT_MIR`, `HCT_Movement_Vacancy_MIR`, `HCT_Form`.
40–43. Отчеты as-is: `REP_Finance Report`, `REP_Name by Name`, `REP_SameStore`, `REP_Samestore Summary`.

Маппинг as-is вкладок на исходные листы `/mnt/agents/upload/Budget forms_обезличено.xlsx`:
IN_*: одноименные листы. FACT_* ← 'МСФО VTBC Comp_Non Comp', 'Загрузка МСФО Банк', 'Загрузка поименная Банк', 'Страхование'. HCT_* ← ' Summary_MIR' (с ведущим пробелом!), 'Summary_GD', 'Summary_MIR_pools', 'Movement_ACT_MIR', 'Movement_ACT_MIR_weekly', 'Movement_TGT_MIR', 'Movement_Vacancy_MIR', 'Form'. REP_* ← 'Finance Report', 'Name by Name ' (trailing space), 'SameStore', 'Samestore Summary'.

## 2. Гиперссылки (навигация)

МЕХАНИЗМ (проверен): использовать ТОЛЬКО объекты Hyperlink с location (внутренние ссылки без внешних relationships):
```python
from openpyxl.worksheet.hyperlink import Hyperlink
c = ws.cell(row=r, column=col, value='R-01 Budget Control Summary')
c.hyperlink = Hyperlink(ref=c.coordinate, location="'R-01_Budget_Control_Summary'!B2", display='R-01 Budget Control Summary')
c.font = Font(color='1F3864', underline='single')
```
ЗАПРЕЩЕНО: `cell.hyperlink = "#'Sheet'!A1"` (создает External relationship) и функция HYPERLINK().

- **01_Report_Registry**: секционные строки-заголовки групп (Стратегический уровень / Тактический / Операционный / Спецификации / Формы внесения данных as-is / Формы загрузки факта as-is / HC Tracker as-is / Отчетные формы as-is / Заменяемые формы). В колонке «Форма» — гиперссылка на соответствующую вкладку (на B2 вкладки). Данные: `/mnt/agents/output/_work/demo_data/report_registry_v2.json`.
- **Каждая вкладка** (включая as-is): ссылка «⇦ Оглавление» → `'01_Report_Registry'!B2`. На листах альбома — чип справа от заголовка (строка 2). На as-is листах — первая пустая ячейка в строке 1 (сканировать колонки A→Z; если строка 1 занята — строка 2; не перезаписывать данные!). Шрифт 9pt NAVY underline.

## 3. Копирование as-is листов (26)

Из `/mnt/agents/upload/Budget forms_обезличено.xlsx`. Принцип: внешний вид и данные — без изменений.
- Значения: загрузить исходник с `data_only=True` и копировать ВЫЧИСЛЕННЫЕ значения (в Movement_* тысячи внутренних формул, есть ссылки на несуществующие листы 'Parameters' — формулы НЕ переносить, только кэш значений; None вместо формулы, если кэша нет).
- Форматирование: font, fill, border, alignment, number_format каждой ячейки (через `copy()` атрибутов стиля), merged_cells, column_dimensions (width), row_dimensions (height), freeze_panes, sheet_view (gridlines — как в оригинале), auto_filter если был.
- Имена вкладок — с префиксами по п.1 (формулы не переносятся, поэтому переименование безопасно).
- На каждой as-is вкладке добавить ТОЛЬКО ссылку «⇦ Оглавление» (п.2), больше ничего не менять.

## 4. Факторный анализ v2 (ключевые изменения контента)

Данные: `waterfall_v2.csv` (12 факторов + Residual, Σ=+165.0, БЕЗ Data Quality), `waterfall_subfactors_v2.csv` (36 подфакторов с FactorID, уровнем автоматизации, владельцем), `factor_dictionary_v2.csv` (12 групп + F99 технический слой), `factor_priority_v2.csv` (14 шагов 0–13), `detection_rules.csv` (R001–R010), `metric_dictionary_add.csv`, `uat_cases_v2.csv` (22), `roadmap_v2.csv`.

- **R-01**: мини-waterfall заменить на v2 (те же данные, что на R-03). Добавить строку-примечание: «Data Quality / Matching — технический фактор, из диаграмм исключен; контроль — на R-08».
- **R-03 (полная переработка layout)**: waterfall v2 (14 столбцов, подписи факторов короткие: F01…F12 + Residual); панель «Как читать» обновить (12 групп, приоритет 0–13, DQ — технический слой); таблица подфакторов v2 с колонками Factor Group / FactorID / Подфактор / Effect / Автоматизация (A5–A2) / Owner / Comment Status + итог SUM = +165.0 с контрольной строкой; блок «Приоритет классификации» — таблица из factor_priority_v2.csv (14 строк, шаг 0 пометить «технический, не отображается»).
- **12_Factor_Dictionary (полная переработка)**: 4 блока: (1) таблица 12 групп + F99 из factor_dictionary_v2.csv (широкие текстовые колонки, wrap); (2) «Приоритет классификации» (factor_priority_v2.csv); (3) «Правила детекции MVP» (detection_rules.csv); (4) «Event Register (demo)» (event_register.csv — сохранить из v1). Плашка-предупреждение: «F99 Data Quality / Matching — технический слой для самопроверки, целевому пользователю не отображается».
- **11_Metric_Dictionary**: дополнить 6 метриками из metric_dictionary_add.csv (Severance Effect, Capitalization Effect, Threshold Effect, Average Earnings Effect, Timing/Rate Effect).
- **15_UAT_Cases**: заменить на uat_cases_v2.csv (22 кейса, включая UAT-02 «DQ не отображается», UAT-04 severance, UAT-05 капитализация excl. отпускные, UAT-06 порог, UAT-07 средний заработок, UAT-21 навигация, UAT-22 as-is).
- **16_Backlog_Roadmap**: заменить на roadmap_v2.csv (волны MVP / Wave 2 / Wave 3 / Run с критериями готовности).
- **03/R-02, 05/R-04 …**: ссылки «Уровень» в подзаголовке; остальной контент без изменений (данные v1 остаются валидными: ФОТ 6 220/6 385, HC 988/1 011 и т.д.).

## 5. Процесс и валидация (как в v1)

- Per-sheet loop: recheck + reference-check после каждого листа; в конце chart-verify (8 графиков) + validate (exit 0). После validate openpyxl файл не открывать.
- Дополнительная проверка навигации: программно пройтись по всем гиперссылкам — каждая location указывает на существующую вкладку; у всех 42 вкладок (кроме 01_Report_Registry) есть обратная ссылка.
- ВАЖНО про y-оси графиков: bridge на R-04 — «ед.», комментарии на R-09 — «шт.», денежные — «млн RUB» (в v1 исправлено патчем, в v2 сделать сразу корректно).
- Итог: `/mnt/agents/output/Альбом_отчетных_форм_бюджетной_системы.xlsx` (перезаписать), скрипты в `_work/build/`.
