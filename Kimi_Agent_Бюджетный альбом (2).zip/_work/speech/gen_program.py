# -*- coding: utf-8 -*-
"""Генератор Program.cs для сборки Стенограмма_презентации_альбома.docx (Create route)."""
import sys
sys.path.insert(0, '/mnt/agents/output/_work/speech')
from content_part1 import PART1
from content_part2 import PART2
from content_part3 import PART3

ALL = PART1 + PART2 + PART3

CHEAT_ROWS = [
    ("Раздел", "Показатель", "Значение / как проговорить"),
    ("Период", "Статус закрытия", "Январь–июнь 2026, закрыт · обновлено 02.07.2026 06:40 · статус «Ready with Warnings»"),
    ("ФОТ", "YTD, млн RUB", "Budget 6 220.0 → Actual 6 385.0 · отклонение +165.0 (+2.7%)"),
    ("ФОТ", "Полный год, млн RUB", "Budget FY 12 945.0 → Forecast FY 13 325.0 · +380.0 (+2.9%)"),
    ("АХР", "YTD, млн RUB", "240.0 → 268.4 · +28.4 (+11.8%)"),
    ("Численность", "HC", "план 1 011 → факт 988 · −23"),
    ("Численность", "MSU", "план 1 002.5 → факт 971.3 · −31.2"),
    ("Waterfall (R-03)", "Крупнейшие факторы", "F03 Оклады +48 · F02 Позиции +41 · F05 Премии +38 · F01 Численность и сроки −38 · Residual −4 (Σ = +165.0)"),
    ("Качество данных (R-08)", "DQ-сводка", "0 критических ошибок · 10 предупреждений · 2 просрочки SLA; DQ на пользовательских диаграммах не отображается"),
    ("Сверка (R-07)", "HR ↔ Finance", "расхождение 27.0 млн RUB — 0.4% от ФОТ; разобрано по типам"),
    ("Комментарии (R-09)", "Workflow", "42 комментария · 18 открыто · 3 эскалации; пороги: ФОТ/АХР > 5% — обязательно, HC/MSU — всегда, эскалация > 5 раб. дней"),
    ("Альбом", "Состав", "43 вкладки = 9 форм R-01…R-09 + 6 спецификаций + 26 as-is (10 внесения + 4 факта + 8 HC Tracker + 4 отчета) + обложка + реестр"),
    ("UAT", "Приемочное тестирование", "24 кейса · вкладка 15_UAT_Cases · 2 недели · все роли"),
    ("Roadmap", "Волны", "MVP (0–6 недель, объясняем 70–80% отклонений) → Wave 2 (Event Register UI, отпускные, капитализация, BI self-service) → Wave 3 (suggested factors, авто-классификация) → Run"),
]

def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')

calls = []
for item in ALL:
    t, x = item
    if t == "title":
        calls.append(f'Title("{esc(x)}");')
    elif t == "subtitle":
        calls.append(f'Subtitle("{esc(x)}");')
    elif t == "titleinfo":
        pairs = ", ".join(f'new[]{{"{esc(k)}", "{esc(v)}"}}' for k, v in x)
        calls.append(f'TitleInfo(new string[][]{{{pairs}}});')
    elif t == "h1":
        calls.append(f'H1("{esc(x)}");')
    elif t == "h2":
        calls.append(f'H2("{esc(x)}");')
    elif t == "note":
        calls.append(f'Note("{esc(x)}");')
    elif t == "s":
        calls.append(f'Sp("{esc(x)}");')
    elif t == "rem":
        calls.append(f'Rem("{esc(x)}");')
    elif t == "b":
        calls.append(f'Bul("{esc(x)}");')
    elif t == "q":
        calls.append(f'Qq("{esc(x)}");')
    elif t == "a":
        calls.append(f'Aa("{esc(x)}");')
    elif t == "cheatsheet":
        rows = ", ".join("new[]{" + ", ".join(f'"{esc(c)}"' for c in r) + "}" for r in CHEAT_ROWS)
        calls.append(f'CheatSheet(new string[][]{{{rows}}});')
    else:
        raise ValueError(f"unknown type {t}")

BODY_CALLS = "\n        ".join(calls)

HEADER = r'''using System;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

class Program
{
    // Палитра (одно hue-направление: navy-slate)
    const string NAVY = "1F3864";      // заголовки
    const string NAVY2 = "2E5395";     // подзаголовки/акценты
    const string BODY = "333333";      // основной текст
    const string GRAY = "5B6B7F";      // подписи
    const string REM_FILL = "EEF2F8";  // заливка ремарок
    const string REM_TEXT = "3D4E63";
    const string HEAD_FILL = "DCE4F0"; // шапка таблицы
    const string BORDER = "B9C4D6";

    static Body body = null!;

    static void Main(string[] args)
    {
        string outputFile = args.Length > 0 ? args[0] : "./output.docx";
        using var doc = WordprocessingDocument.Create(outputFile, WordprocessingDocumentType.Document);
        var mainPart = doc.AddMainDocumentPart();
        mainPart.Document = new Document(new Body());
        body = mainPart.Document.Body!;

        AddStyles(mainPart);
        var headerId = AddHeader(mainPart);
        var footerId = AddFooter(mainPart);

        // ===== Контент =====
        BODY_CALLS_PLACEHOLDER

        // ===== Секция (header/footer + страница) =====
        body.Append(new SectionProperties(
            new HeaderReference { Type = HeaderFooterValues.Default, Id = headerId },
            new FooterReference { Type = HeaderFooterValues.Default, Id = footerId },
            new PageSize { Width = 11906, Height = 16838 },
            new PageMargin { Top = 1200, Right = 1440, Bottom = 1200, Left = 1440, Header = 720, Footer = 600 }));

        doc.Save();
        Console.WriteLine("OK: " + outputFile);
    }
'''

HELPERS = r'''
    // ---------- Стили ----------
    static void AddStyles(MainDocumentPart mainPart)
    {
        var stylesPart = mainPart.AddNewPart<StyleDefinitionsPart>();
        stylesPart.Styles = new Styles();

        stylesPart.Styles.Append(new Style(
            new StyleName { Val = "Normal" },
            new StyleParagraphProperties(
                new SpacingBetweenLines { After = "140", Line = "300", LineRule = LineSpacingRuleValues.Auto }),
            new StyleRunProperties(
                new RunFonts { Ascii = "Calibri", HighAnsi = "Calibri", EastAsia = "Microsoft YaHei" },
                new Color { Val = BODY },
                new FontSize { Val = "22" })
        ) { Type = StyleValues.Paragraph, StyleId = "Normal" });

        stylesPart.Styles.Append(new Style(
            new StyleName { Val = "heading 1" },
            new BasedOn { Val = "Normal" },
            new NextParagraphStyle { Val = "Normal" },
            new StyleParagraphProperties(
                new KeepNext(), new KeepLines(),
                new ParagraphBorders(
                    new BottomBorder { Val = BorderValues.Single, Size = 8, Color = NAVY, Space = 4 }),
                new SpacingBetweenLines { Before = "420", After = "180", Line = "240", LineRule = LineSpacingRuleValues.Auto },
                new OutlineLevel { Val = 0 }),
            new StyleRunProperties(
                new RunFonts { Ascii = "Calibri", HighAnsi = "Calibri", EastAsia = "Microsoft YaHei" },
                new Bold(),
                new Color { Val = NAVY },
                new FontSize { Val = "30" })
        ) { Type = StyleValues.Paragraph, StyleId = "Heading1" });

        stylesPart.Styles.Append(new Style(
            new StyleName { Val = "heading 2" },
            new BasedOn { Val = "Normal" },
            new NextParagraphStyle { Val = "Normal" },
            new StyleParagraphProperties(
                new KeepNext(), new KeepLines(),
                new SpacingBetweenLines { Before = "320", After = "140", Line = "240", LineRule = LineSpacingRuleValues.Auto },
                new OutlineLevel { Val = 1 }),
            new StyleRunProperties(
                new RunFonts { Ascii = "Calibri", HighAnsi = "Calibri", EastAsia = "Microsoft YaHei" },
                new Bold(),
                new Color { Val = NAVY2 },
                new FontSize { Val = "26" })
        ) { Type = StyleValues.Paragraph, StyleId = "Heading2" });

        stylesPart.Styles.Save();
    }

    static string AddHeader(MainDocumentPart mainPart)
    {
        var part = mainPart.AddNewPart<HeaderPart>();
        var p = new Paragraph(
            new ParagraphProperties(
                new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 4, Color = BORDER, Space = 2 }),
                new SpacingBetweenLines { After = "0", Line = "240", LineRule = LineSpacingRuleValues.Auto },
                new Justification { Val = JustificationValues.Right }),
            MkRun("Стенограмма презентации альбома отчетных форм · версия 1.0 · июль 2026", sz: "17", color: GRAY));
        part.Header = new Header(p);
        part.Header.Save();
        return mainPart.GetIdOfPart(part);
    }

    static string AddFooter(MainDocumentPart mainPart)
    {
        var part = mainPart.AddNewPart<FooterPart>();
        var p = new Paragraph(new ParagraphProperties(
            new SpacingBetweenLines { After = "0", Line = "240", LineRule = LineSpacingRuleValues.Auto },
            new Justification { Val = JustificationValues.Center }));
        p.Append(MkRun("Стр. ", sz: "18", color: GRAY));
        p.Append(new Run(new RunProperties(new FontSize { Val = "18" }, new Color { Val = GRAY }),
            new FieldChar { FieldCharType = FieldCharValues.Begin }));
        p.Append(new Run(new RunProperties(new FontSize { Val = "18" }, new Color { Val = GRAY }),
            new FieldCode(" PAGE ") { Space = SpaceProcessingModeValues.Preserve }));
        p.Append(new Run(new RunProperties(new FontSize { Val = "18" }, new Color { Val = GRAY }),
            new FieldChar { FieldCharType = FieldCharValues.End }));
        part.Footer = new Footer(p);
        part.Footer.Save();
        return mainPart.GetIdOfPart(part);
    }

    // ---------- Примитивы ----------
    static Run MkRun(string text, string sz = "22", string color = BODY, bool bold = false, bool italic = false)
    {
        var rp = new RunProperties();
        rp.Append(new RunFonts { Ascii = "Calibri", HighAnsi = "Calibri", EastAsia = "Microsoft YaHei" });
        if (bold) rp.Append(new Bold());
        if (italic) rp.Append(new Italic());
        rp.Append(new Color { Val = color });
        rp.Append(new FontSize { Val = sz });
        return new Run(rp, new Text(text) { Space = SpaceProcessingModeValues.Preserve });
    }

    static void Title(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(
                new KeepNext(),
                new SpacingBetweenLines { Before = "120", After = "80", Line = "280", LineRule = LineSpacingRuleValues.Auto }),
            MkRun(text, sz: "52", color: NAVY, bold: true)));
    }

    static void Subtitle(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(new SpacingBetweenLines { After = "360", Line = "260", LineRule = LineSpacingRuleValues.Auto }),
            MkRun(text, sz: "27", color: GRAY)));
    }

    static void TitleInfo(string[][] rows)
    {
        var tbl = new Table();
        tbl.Append(new TableProperties(
            new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
            new TableBorders(
                new TopBorder { Val = BorderValues.Single, Size = 12, Color = NAVY },
                new BottomBorder { Val = BorderValues.Single, Size = 12, Color = NAVY },
                new LeftBorder { Val = BorderValues.Nil },
                new RightBorder { Val = BorderValues.Nil },
                new InsideHorizontalBorder { Val = BorderValues.Single, Size = 2, Color = BORDER },
                new InsideVerticalBorder { Val = BorderValues.Nil }),
            new TableCellMarginDefault(
                new TableCellLeftMargin { Width = 100, Type = TableWidthValues.Dxa },
                new TableCellRightMargin { Width = 100, Type = TableWidthValues.Dxa })));
        tbl.Append(new TableGrid(
            new GridColumn { Width = "2100" },
            new GridColumn { Width = "6900" }));
        foreach (var r in rows)
        {
            tbl.Append(new TableRow(
                MkCell(r[0], "2100", bold: true, color: NAVY2),
                MkCell(r[1], "6900")));
        }
        body.Append(tbl);
        body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { After = "120" })));
    }

    static TableCell MkCell(string text, string width, bool bold = false, string color = BODY, string fill = null, string sz = "20")
    {
        var tcp = new TableCellProperties(new TableCellWidth { Width = width, Type = TableWidthUnitValues.Dxa });
        if (fill != null) tcp.Append(new Shading { Val = ShadingPatternValues.Clear, Fill = fill });
        var p = new Paragraph(
            new ParagraphProperties(new SpacingBetweenLines { Before = "40", After = "40", Line = "260", LineRule = LineSpacingRuleValues.Auto }),
            MkRun(text, sz: sz, color: color, bold: bold));
        return new TableCell(tcp, p);
    }

    static void H1(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(new ParagraphStyleId { Val = "Heading1" }),
            new Run(new Text(text) { Space = SpaceProcessingModeValues.Preserve })));
    }

    static void H2(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(new ParagraphStyleId { Val = "Heading2" }),
            new Run(new Text(text) { Space = SpaceProcessingModeValues.Preserve })));
    }

    static void Note(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(new SpacingBetweenLines { After = "160", Line = "260", LineRule = LineSpacingRuleValues.Auto }),
            MkRun(text, sz: "19", color: GRAY, italic: true)));
    }

    static void Sp(string text)
    {
        body.Append(new Paragraph(MkRun(text)));
    }

    static void Rem(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(
                new KeepLines(),
                new ParagraphBorders(new LeftBorder { Val = BorderValues.Single, Size = 12, Color = NAVY2, Space = 4 }),
                new Shading { Val = ShadingPatternValues.Clear, Fill = REM_FILL },
                new SpacingBetweenLines { Before = "60", After = "160", Line = "260", LineRule = LineSpacingRuleValues.Auto },
                new Indentation { Left = "284", Right = "284" }),
            MkRun("[" + text + "]", sz: "20", color: REM_TEXT, italic: true)));
    }

    static void Bul(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(
                new SpacingBetweenLines { After = "100", Line = "280", LineRule = LineSpacingRuleValues.Auto },
                new Indentation { Left = "368", Hanging = "184" }),
            MkRun("•  " + text)));
    }

    static void Qq(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(
                new KeepNext(),
                new SpacingBetweenLines { Before = "240", After = "60", Line = "280", LineRule = LineSpacingRuleValues.Auto }),
            MkRun(text, bold: true, color: NAVY2)));
    }

    static void Aa(string text)
    {
        body.Append(new Paragraph(
            new ParagraphProperties(new SpacingBetweenLines { After = "160" }),
            MkRun(text)));
    }

    static void CheatSheet(string[][] rows)
    {
        var tbl = new Table();
        tbl.Append(new TableProperties(
            new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
            new TableBorders(
                new TopBorder { Val = BorderValues.Single, Size = 10, Color = NAVY },
                new BottomBorder { Val = BorderValues.Single, Size = 10, Color = NAVY },
                new LeftBorder { Val = BorderValues.Nil },
                new RightBorder { Val = BorderValues.Nil },
                new InsideHorizontalBorder { Val = BorderValues.Single, Size = 2, Color = BORDER },
                new InsideVerticalBorder { Val = BorderValues.Nil }),
            new TableCellMarginDefault(
                new TableCellLeftMargin { Width = 100, Type = TableWidthValues.Dxa },
                new TableCellRightMargin { Width = 100, Type = TableWidthValues.Dxa })));
        tbl.Append(new TableGrid(
            new GridColumn { Width = "1900" },
            new GridColumn { Width = "2300" },
            new GridColumn { Width = "4800" }));
        for (int i = 0; i < rows.Length; i++)
        {
            var r = rows[i];
            if (i == 0)
            {
                tbl.Append(new TableRow(
                    new TableRowProperties(new TableHeader()),
                    MkCell(r[0], "1900", bold: true, color: NAVY, fill: HEAD_FILL),
                    MkCell(r[1], "2300", bold: true, color: NAVY, fill: HEAD_FILL),
                    MkCell(r[2], "4800", bold: true, color: NAVY, fill: HEAD_FILL)));
            }
            else
            {
                tbl.Append(new TableRow(
                    new TableRowProperties(new CantSplit()),
                    MkCell(r[0], "1900", bold: true, color: NAVY2),
                    MkCell(r[1], "2300"),
                    MkCell(r[2], "4800")));
            }
        }
        body.Append(tbl);
        body.Append(new Paragraph(
            new ParagraphProperties(new SpacingBetweenLines { Before = "160" }),
            MkRun("Конец стенограммы. Удачного выступления!", sz: "19", color: GRAY, italic: true)));
    }
}
'''

program = HEADER.replace("BODY_CALLS_PLACEHOLDER", BODY_CALLS) + HELPERS

with open('/tmp/docx-work/Program.cs', 'w', encoding='utf-8') as f:
    f.write(program)
with open('/mnt/agents/output/_work/speech/Program.cs.bak', 'w', encoding='utf-8') as f:
    f.write(program)

print("Program.cs written:", len(program), "chars")
