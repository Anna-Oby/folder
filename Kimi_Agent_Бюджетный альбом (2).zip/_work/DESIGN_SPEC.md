# DESIGN SPEC — Альбом отчетных форм бюджетной системы (Excel workbook)

Целевой файл: `/mnt/agents/output/Альбом_отчетных_форм_бюджетной_системы.xlsx`
17 листов в указанном порядке. Язык — русский; системные термины — английский (Budget, Forecast, Actual, Dashboard, Drill-down, Reconciliation, Data Quality, Factor Engine, MSU, MIR-code).
Все числовые данные брать ТОЛЬКО из CSV/JSON в `/mnt/agents/output/_work/demo_data/` — они взаимно согласованы. Ничего не выдумывать.
Единицы: деньги — млн RUB (указывать в заголовках «млн RUB»), HC — ед., MSU — доля (1 знак), % — 1 знак.
Это мокап-альбом (BI prototype): на дашборд-листах данные демонстрационные; на каждом дашборд-листе в футере: «Демо-данные · Альбом отчетных форм v1.0».

## 1. Визуальная система

### Палитра (hex без #)
- `NAVY = "1F3864"` — заголовки, totals в waterfall/bridge, основной акцент
- `BLUE_MED = "2F5597"`, `BLUE_SOFT = "8FAADC"`, `BLUE_PALE = "DCE6F2"` — графики, фон панелей
- `TEAL = "17858C"`, `TEAL_SOFT = "5FB3B3"` — второй акцент, позитивные факторы
- `GRAPHITE = "3B3F46"` — основной текст; `GRAY = "7A828E"` — вторичный текст
- `BG_LIGHT = "F5F7FA"` — фон панелей/карточек; `WHITE = "FFFFFF"`
- `BORDER = "C9D2DE"` — тонкие границы карточек/таблиц
- Статусы (только для статусов и рисков): `GREEN = "2E7D32"` / заливка `E6F2E6`; `AMBER = "B7791F"` / заливка `FDF3D8`; `RED = "C0392B"` / заливка `FBE4E1`

### Типографика
- Шрифт везде: Calibri. Заголовок листа 16pt bold NAVY; подзаголовок 10pt GRAY; секционные заголовки 11pt bold GRAPHITE; тело таблиц 10pt; мелкие примечания 8.5–9pt GRAY.

### Базовая сетка листа
- `ws.sheet_view.showGridLines = False` на ВСЕХ листах.
- Колонка A — margin, ширина 2. Контент с B2.
- B2 — заголовок листа (merge B2:N2), row 2 height 28. B3 — подзаголовок/контекст (merge).
- Футер: через 2 строки после контента, 8.5pt GRAY: «Демо-данные · Альбом отчетных форм v1.0 · <ID листа> · Обновлено: 02.07.2026 06:40».

### Компоненты (реализовать как helper-функции)
1. **filter_bar(ws, row, items)** — ряд «фильтров-чипов»: каждая ячейка — текст «Год: 2026 ▾», заливка BLUE_PALE, шрифт 9pt NAVY, тонкая рамка BORDER, center. Использовать на всех дашборд-листах (02–10). Типовой набор: «Год: 2026 ▾», «Период: Янв–Июн ▾», «Сценарий: Actual vs Budget Final ▾», «Версия: Budget Final v1.0 ▾», «Legal Entity: Все ▾», «MIR-code: Все ▾», «HRBP perimeter: Все ▾» (поднабор по смыслу листа) + в конце бара: «Обновлено: 02.07.2026 06:40» (plain, GRAY) и чип статуса закрытия.
2. **status_chip(ws, cell, text, level)** — level green/amber/red: заливка E6F2E6/FDF3D8/FBE4E1, шрифт bold соответствующего цвета, center, рамка цвета уровня.
3. **kpi_card(ws, top_left_col, row, width, label, value, delta_text, delta_sign)** — блок width×3: белая заливка, рамка BORDER, верхняя граница thick TEAL (или NAVY). Строка 1: label 8.5pt GRAY caps; строка 2: value 18pt bold NAVY (format по типу); строка 3: delta 9pt: позитив-перерасход RED «▲ +165.0 (+2.7%)», недорасход GREEN «▼». Для HC/MSU знак трактовать как «отклонение от плана»: минус — красный? НЕТ: для затрат перерасход — риск (RED); для HC недобор — нейтрально-информативно: использовать AMBER. В подписи delta явно словами: «к Budget YTD», «к Plan».
4. **section_title(ws, row, text)** — merge, 11pt bold GRAPHITE, нижняя граница medium NAVY.
5. **table(ws, df, top_left, header_fill=NAVY)** — заголовок: заливка NAVY, шрифт white bold 9.5pt, center; тело: 10pt, чередование заливки WHITE/BG_LIGHT, тонкие горизонтальные границы BORDER; выравнивание чисел вправо; форматы чисел.
6. **traffic(ws, cell, level)** — символ «●» 14pt цвета GREEN/AMBER/RED + рядом текст статуса.

### Графики (openpyxl.chart, обязательно `chart-verify`)
- Данные для диаграмм размещать на том же листе в служебной зоне, начиная с колонки `AA` (27): мелкий серый заголовок «данные для диаграмм (не печатать)». Диапазоны должны быть непрерывными.
- Палитра серий: NAVY, TEAL, GRAPHITE, BLUE_SOFT; статусные серии: позитив TEAL, негатив RED.
- **Waterfall / bridge**: BarChart `type="col"`, `grouping="stacked"`, `overlap=100`; серия Base — `graphicalProperties.noFill=True`; серия Bar — раскрасить точечно через `openpyxl.chart.marker.DataPoint` (idx): totals → NAVY, позитив → TEAL, негатив → RED. Подписи данных: `dLbls showVal=True` на серии Bar.
- **Trend**: LineChart, 3 серии: Budget (NAVY, сплошная), Actual (TEAL, толщина 28000 EMU), Forecast (GRAPHITE, dashStyle="dash"). Месяцы по X.
- **Сгруппированные бары** (АХР, reconciliation): BarChart clustered, 2 серии NAVY/TEAL.
- Размеры: width≈15–17 cm, height≈8–9 cm; якорь в указанных ячейках; у графиков белый фон, без рамки.

### Числовые форматы
- Деньги: `#,##0.0` (1 знак), крупные итоги `#,##0`; %: `0.0"%"` (значения хранить как числа в %-пунктах, НЕ долями — во избежание путаницы; в заголовке «%»). HC: `#,##0`; MSU: `#,##0.0`.
- Формулы Excel обязательны там, где значение вычисляется из соседних ячеек на листе: Variance = Actual−Budget, Variance %, итоги SUM по таблицам, KPI-карточки могут ссылаться на итоги таблиц (=ссылка) — так альбом остается «живым». Исходные числа из CSV — статичные (это демо-выгрузка).
- Запрещенные функции (Excel<2019) не использовать. Никаких PivotTable.

## 2. Структура листов

### Лист `00_README` (обложка)
- B2: «Альбом отчетных форм бюджетной системы» 20pt bold NAVY (merge B2:N2, высота 36).
- B3: «Бюджетная система по затратам на персонал · версия 1.0 (MVP) · июль 2026» 11pt GRAY.
- Блок «Назначение»: 4–5 строк текста — целостный комплект отчетности для контроля исполнения бюджета по затратам на персонал: budget control cockpit, а не набор Excel-таблиц. Пользователи: Head of HR Operations, HRD, Head of Reward, HRBP, Reward, Finance, HRIS, Recruitment, LoD.
- Блок «Ключевые принципы» (маркированный список, 8 пунктов): 1) видна не только сумма, но и причина отклонения; 2) HR-факт — основа факторного анализа; 3) Finance-факт — слой reconciliation; 4) отображаются все отклонения; 5) комментарий обязателен: ФОТ/АХР >5%, HC/MSU — всегда; 6) drill-down до сотрудника/вакансии/MIR/LE/P&L/budget element; 7) Data Quality Status до управленческих решений; 8) MSU вместо FTE.
- Блок «Демо-контекст»: отчетный год 2026; закрыт период янв–июнь 2026; сценарий июля: Actual Jan–Jun + Forecast Jul–Dec vs Budget Final v1.0; валюта млн RUB; все данные синтетические.
- Блок «Навигация по листам»: таблица из 17 строк (лист | содержание) — из реестра ниже.
- Блок «Ключевые демо-показатели»: 6 мини-KPI (Budget YTD 6 220.0; Actual YTD 6 385.0; Δ +165.0 (+2.7%); Forecast FY 13 325.0 vs Budget FY 12 945.0; HC 988/1 011; Closing: Ready with Warnings).
- Блок «Легенда»: цвета статусов (green/amber/red chips), ▲/▼, чипы фильтров; примечание «АХР — административно-хозяйственные расходы, связанные с персоналом».

### Лист `01_Report_Registry`
- Данные: `report_registry.csv` (14 строк). Таблица с фильтром (auto_filter), закрепить шапку.
- Колонки как в CSV. Ширины: name 28, purpose 45, question 40, sources 35, grain 40.
- Ниже — легенда: P0 = MVP-критично, P2 = поддерживается; MVP/R2/R3 — релиз; статусы as-is: «Новая / Остается / Заменяется».

### Лист `02_Budget_Control_Summary` (дашборд)
- Подзаголовок: «R-01 · Управленческий обзор исполнения бюджета · пользователи: Head of HR Operations, HRD, Head of Reward».
- filter_bar (row 5): Год 2026, Период Янв–Июн, Сценарий Actual vs Budget Final, Версия Budget Final v1.0, LE Все, MIR Все + «Обновлено…» + status_chip «Ready with Warnings» amber.
- KPI row (rows 7–10, 6 карточек по 3 колонки): Budget YTD 6 220.0; Actual YTD 6 385.0 (▲ +165.0 / +2.7% к Budget, RED); Forecast FY 13 325.0 (▲ +380.0 / +2.9% к Budget FY, RED); HC 988 (к Plan 1 011: −23, AMBER); MSU 971.3 (к Plan 1 002.5: −31.2, AMBER); АХР 268.4 (▲ +28.4 / +11.8% к Budget, RED). Значения — формулами-ссылками на итоги служебных таблиц листа, где возможно.
- Секция «Динамика ФОТ: Budget / Actual / Forecast, млн RUB» — LineChart из `trend_fot_monthly.csv` (данные в AA-зоне). Якорь ~B12.
- Секция «Факторы отклонения ФОТ YTD (waterfall), млн RUB» — waterfall BarChart из `waterfall_fot_ytd.csv` (Base/Bar). Якорь ~J12.
- Секция «Top-5 отклонений» — таблица `top_deviations.csv` со status chips в колонке Comment Status. ~B30.
- Секция «Статус контроля» (4 плитки в ряд): Data Quality — «Ready with Warnings» amber + «10 warnings · 0 critical»; Reconciliation — amber «+27.0 млн (0.4%) · 4 open issues»; Комментарии — amber «42 обязательных · 18 open · 3 escalated»; Closing Readiness — amber «Ready with Warnings». ~J30.
- Примечание 9pt GRAY: «АХР в KPI включен справочно; детальный разбор — на листе 07».

### Лист `03_Plan_Fact_Explorer` (дашборд)
- Подзаголовок: «R-02 · Интерактивный анализ отклонений · Reward, Finance, HRBP, HR Operations».
- filter_bar: стандартный набор + «Budget Element: Все ▾», «P&L Account: Все ▾».
- KPI row (5 карточек): Budget YTD 6 220.0; Actual YTD 6 385.0; Variance +165.0; Variance 2.7%; «Отклонений с обязательным комментарием: 18».
- Секция «Heatmap отклонений, млн RUB: Budget Element × Legal Entity» — матрица из `heatmap_element_le_variance.csv` (9 строк × 6 LE) + итоговая строка/столбец формулами SUM. Conditional formatting ColorScaleRule: min TEAL → mid white (0) → max RED.
- Секция «Детализация (demo-срез)» — таблица `plan_fact_detail.csv` + вычисляемые колонки Variance, Variance % (формулы), DataBarRule на Variance, chips «Да/Нет» в Comment Required.
- Примечание: drill-down path: Month → Legal Entity → MIR-code → P&L Account → Budget Element → Employee / Vacancy (показать как строку-пасхалку «Drill-down: …»).

### Лист `04_Variance_Waterfall` (дашборд)
- Подзаголовок: «R-03 · Факторный анализ отклонения ФОТ (HR-факт) · Head of HR Operations, Reward, Finance, HRBP».
- filter_bar: Год, Период, Сценарий, Версия, LE, MIR, Factor Group: Все ▾.
- Слева: большой waterfall chart (`waterfall_fot_ytd.csv`), якорь B7.
- Справа: панель «Как читать»: факторный анализ строится на HR-факте; Finance-факт — reconciliation (лист 08); HC и MSU — расчетные драйверы/диагностика, не конкурирующие факторы; каждый рубль отклонения относится к одному primary factor (приоритет ниже); АХР факторизуется на листе 07.
- Секция «Подфакторы» — таблица `waterfall_subfactors.csv` (23 строки) с chips по Comment Status; итог SUM формулой = +165.0 и контрольная строка «= Variance YTD».
- Секция «Приоритет классификации (anti-double-counting)» — нумерованный список 11 шагов: 1 Data Quality / Matching; 2 Manual / One-off / Registered Event; 3 Unplanned Hire / Unplanned Position; 4 Population & Timing; 5 Allocation / MSU / Charging; 6 Salary Rate / Increase; 7 Bonus / Incentives; 8 Social Security / Regulator; 9 Benefits; 10 АХР / Non-compensation; 11 Residual / Needs Review. Пример: сотрудник вне бюджета с высоким окладом → primary factor = Unplanned Hire.
- Примечание про Residual: tolerance ±0.5% от Budget YTD (±31.1); текущий residual −5.0 в пределах допуска, статус Needs Comment назначен.

### Лист `05_HC_Vacancy_Bridge` (дашборд)
- Подзаголовок: «R-04 · Движение численности, вакансий и MSU · HRBP, Recruitment, Head of HR Operations».
- filter_bar + «HRBP perimeter: Все ▾».
- KPI row (6): Opening HC 952; Hires +80; Leavers −36; Closing HC 988; Plan 1 011 (Δ −23, AMBER); MSU 971.3 (к Plan −31.2, AMBER).
- Bridge chart (`hc_bridge.csv` Base/Bar; plan — отдельной короткой серией-маркером можно опустить; вместо этого KPI «Plan 1 011»). Якорь B12.
- Таблица «Отклонение HC от плана по подфакторам» (`hc_variance_subfactors.csv`) + итог −23 формулой; chips.
- Панель «Вакансии» (`vacancy_stats.csv`) + «MSU movement» (`msu_movement.csv`) рядом.
- Таблица «Drill-down до сотрудника/вакансии (demo)» (`drilldown_hc_vacancy.csv`).

### Лист `06_Compensation_Detail` (отчет)
- Подзаголовок: «R-05 · Детализация ФОТ по бюджетным элементам · Reward, Finance, HR Operations».
- filter_bar + «Budget Element: Все ▾».
- Матрица «Actual по месяцам, млн RUB»: `elements_monthly_actual.csv` (19 элементов × Янв–Июн) + столбцы YTD Actual (SUM формула), Budget YTD (из `budget_elements_ytd.csv`), Variance (формула), Variance % (формула). ColorScale на колонке Variance %.
- BarChart «Variance by element, млн RUB» (топ по модулю, из AA-зоны — отсортировать в коде, 10 элементов), якорь справа.
- Таблица «Drill-down до сотрудника/назначения (demo)» (`drilldown_employee.csv`).
- Примечание: полный перечень элементов — по методологии бюджетной системы (19 элементов, включая Capitalized compensation и Payments to Board Members).

### Лист `07_АХР_Dashboard` (дашборд)
- Подзаголовок: «R-06 · Контроль некомпенсационных расходов · HR Operations, Finance, LoD, Recruitment».
- filter_bar: Год, Период, LE, MIR, «АХР Category: Все ▾», «Owner: Все ▾».
- KPI row (4): Budget YTD 240.0; Actual YTD 268.4; Variance +28.4 (+11.8%, RED); «Категорий с перерасходом: 3 из 4».
- Clustered BarChart Budget vs Actual по 4 категориям (`axr_categories.csv`). Якорь B12.
- Таблица категорий с подфакторами, owner, chips Comment Status.
- Панель «MVP-логика»: АХР Variance = Actual − Budget; стабильных драйверов нет — volume/rate декомпозиция перенесена в R2; перечень подфакторов (overspend, underspend, unplanned, planned not spent, timing, one-off, contractors variance, manual Finance adjustment). «Detail level»: LE / MIR / P&L / Category / Owner — доступно; до сотрудника — не требуется.

### Лист `08_Reconciliation` (дашборд)
- Подзаголовок: «R-07 · Сверка HR-факта и Finance-факта · Finance, Reward, HRIS, Head of HR Operations».
- filter_bar: Год, Период, LE, MIR, «Difference Type: Все ▾», «Status: Все ▾».
- KPI row (5): HR Actual YTD 6 385.0; Finance Actual YTD 6 412.0; Difference +27.0 (0.42%, AMBER); Open issues 4 (RED если >0? оставить AMBER); Controlled exceptions 3.
- Таблица-матрица `recon_matrix.csv` (ФОТ/АХР/Итого).
- BarChart «Расхождения по типам, млн RUB» (`recon_difference_types.csv`, горизонтальные бары, type="bar").
- Таблица типов расхождений с описанием, owner, chips Status (Open — RED chip, Resolved — GREEN, Controlled exception — BLUE_PALE chip).
- Панель «Controlled exceptions (ожидаемые расхождения)»: discretionary bonus; deferred bonus; benefits; other compensation; capitalized compensation; recruitment expenses; training; workshops/offsites.
- Панель «Closing status»: Ready with Warnings — условия: unclassified residual −2.0 млн (< 0.05% — допустимо), 4 open issues со SLA.

### Лист `09_Data_Quality` (дашборд)
- Подзаголовок: «R-08 · Качество данных и готовность к закрытию · HRIS, HR Operations, Reward, Finance».
- filter_bar: Период, Source System: Все ▾, Error Type: Все ▾, Owner: Все ▾.
- 4 статусные плитки (traffic): Ready to Close — серо-неактивна; Ready with Warnings — AMBER активна; Blocked — неактивна; Under Investigation — неактивна. Активную выделить рамкой.
- KPI: Critical errors 0 (GREEN); Warnings 10 (AMBER); Просрочено SLA 2 (RED); Правило закрытия: «critical = 0 ∧ recon residual < tolerance ∧ покрытие комментариев ≥ 90%».
- Таблица проверок `data_quality.csv` (13 строк) с traffic ● в колонке Light, chips по статусу.
- Примечание: DQ Status показывается пользователю ДО управленческих решений (дублируется на R-01).

### Лист `10_Comments_Actions` (дашборд)
- Подзаголовок: «R-09 · Workflow комментариев и действий · HRBP, Reward, Finance, HR Operations».
- filter_bar: Период, Owner: Все ▾, Status: Все ▾, «Только обязательные: Да ▾».
- KPI row (5): Всего обязательных 42; Commented 24 (GREEN); Under Review 8; Needs Comment 7 (AMBER); Escalated 3 (RED).
- BarChart по статусам (`comments_by_status.csv`).
- Панель «Правила обязательности»: ФОТ и АХР — |отклонение| > 5%; HC и MSU — любое отклонение; маршрутизация владельцев (8 строк: HC/вакансии/наймы/увольнения → HRBP; salary/uplift/bonus/benefits → Reward; MIR/charging/справочники → Reward+HRIS; P&L/accounts/posting → Finance; технические загрузки → HRIS; recruitment АХР → Recruitment/Finance; training АХР → LoD/Finance; executive summary → Head of HR Operations/Reward). Эскалация: Needs Comment > 5 раб. дней → Escalated.
- Таблица `comments_actions.csv` (8 строк) со status chips, aging, escalation flag (RED «Да»).

### Лист `11_Metric_Dictionary`
- Таблица `metric_dictionary.csv` (32 метрики). Широкие колонки Formula/Определение (45–55). Автофильтр.

### Лист `12_Factor_Dictionary`
- Таблица `factor_dictionary.csv` (10 групп). 
- Ниже — блок «Event Register (demo)»: таблица `event_register.csv` + принцип: событие не зарегистрировано → фактор не присваивается, отклонение → Needs Review.
- Примечание: HC и MSU — драйверы расчета и диагностические показатели, не отдельные факторы; реальные подфакторы — early hire, delayed hire, vacancy not filled, unplanned hire, early/delayed/unplanned leaver, transfer, MSU change, charging change.

### Лист `13_Field_Dictionary`
- Таблица `field_dictionary.csv` (39 строк), сгруппировать визуально по Source (секционные строки-заголовки групп с заливкой BLUE_PALE).

### Лист `14_Access_Rights`
- Матрица `access_rights.csv`: роли × 9 форм (R / R/W / — / R+approve / comment). Заливка ячеек: R/W → BLUE_PALE, R+approve → TEAL_SOFT, «—» → BG_LIGHT.
- Легенда: R — чтение; W — запись/корректировка; comment — комментирование отклонений; approve — подтверждение комментариев/закрытия; Data scope — периметр данных.

### Лист `15_UAT_Cases`
- Таблица `uat_cases.csv` (20 кейсов). Колонка «Статус» — «готов к выполнению». Автофильтр.

### Лист `16_Backlog_Roadmap`
- 3 карточки-релиза из `roadmap.csv` (MVP / R2 / R3): заголовок релиза NAVY, срок чипом, scope маркированным списком.
- Ниже — таблица «Зависимости и допущения»: 5–6 строк (Event Register UI нужен для авто-классификации R2; Benefits поименно требует доработки выгрузки страховщика; АХР volume/rate требует драйверов от Finance; BI self-service требует выбора платформы; интеграция Hyperion — R3).

## 3. Технический процесс (обязателен)
1. Собирать workbook скриптом(ами) Python/openpyxl через ipython. CSV читать pandas'ом.
2. После КАЖДОГО листа: `wb.save()` + `shell: /app/.agents/skills/xlsx/scripts/Xlsx recheck <file>` и `reference-check <file>`; ошибки — исправить до 0, затем следующий лист.
3. После всех листов: `chart-verify` (все диаграммы с данными) и `validate` (exit 0). Не открывать файл openpyxl после финального validate.
4. Каждая таблица должна содержать данные (нет пустых таблиц). Никаких «TBD».
5. Итог: `/mnt/agents/output/Альбом_отчетных_форм_бюджетной_системы.xlsx`.
