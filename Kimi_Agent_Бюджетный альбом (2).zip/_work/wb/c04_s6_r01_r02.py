# ============================== SECTION 6 ==============================
pagebreak()
h1("6. Report form cards")
p("Раздел содержит карточки всех девяти отчетных форм. Каждая карточка включает полный набор атрибутов (уровень отчетности, назначение, пользователи, бизнес-вопросы, зерно, метрики, формулы, компоновка, drill-down, комментарии, качество данных, права, MVP scope, развитие), пояснения по работе с формой и демонстрационный пример на согласованных демо-данных (закрытие июня 2026, сценарий Actual vs Budget Final v1.0). Состав атрибутов един для всех форм. Атрибут «Уровень отчетности» принимает значения Стратегический / Тактический / Операционный по уровневой модели раздела 3.2 и дублируется в подзаголовке вкладки формы в Excel-альбоме.")

# ---------------- R-01 ----------------
h2("6.1. R-01 Budget Control Summary")
attr([
 ("Report name","Budget Control Summary"),
 ("Report ID","R-01"),
 ("Уровень отчетности","Стратегический — summary и верхнеуровневые данные для executive и комитетов"),
 ("Purpose","Дать управленческий обзор исполнения бюджета по затратам на персонал: одна страница для оценки ситуации за 2–3 минуты"),
 ("Main users","Head of HR Operations, HRD, Head of Reward"),
 ("Business questions","Как исполняется бюджет YTD и что формирует отклонение? Куда придем по итогам года (FY Outlook)? Какие сегменты проблемные? Можно ли доверять данным и закрывать период? Все ли обязательные комментарии собраны?"),
 ("Decisions supported","Запуск корректирующих действий по топ-факторам; запрос deep-dive (R-02/R-03); согласие / отказ на закрытие периода; эскалация просроченных комментариев"),
 ("Frequency","Ежемесячно после закрытия; в период закрытия — ежедневное обновление (демо: 02.07.2026 06:40)"),
 ("Data sources","Budget DB (MG Compensation), HRPT, HR Tracker, Finance files, Factor Engine, Recon service, DQ engine, Comment store"),
 ("Grain","Агрегат за выбранный период × Legal Entity × MIR-code × Global Unit; показатели YTD и FY"),
 ("Filters","Year · Month / период · Scenario · Version · Legal Entity · MIR-code · Global Unit · HRBP perimeter"),
 ("Metrics","Budget YTD · Actual YTD · Variance Amount · Variance % · Forecast FY · FY Outlook Variance · HC Plan / Actual · MSU Plan / Actual · АХР YTD (справочно) · Top-5 факторов · Top-5 отклонений · DQ Status · Reconciliation Status · Open Comments · Closing Readiness"),
 ("Formulas","Variance Amount = Actual − Budget; Variance % = (Actual − Budget) / Budget; FY Outlook = Actual YTD + Σ Forecast(N+1..Dec); FY Outlook Variance = Forecast FY − Budget FY"),
 ("Visual layout","Top panel: фильтры + дата обновления + чип Closing Status. Ряд 1: 6 KPI cards. Ряд 2: trend Budget / Actual / Forecast по месяцам + waterfall факторов YTD. Ряд 3: таблица Top-5 отклонений + 4 плитки статусов (Data Quality, Reconciliation, Комментарии, Closing Readiness)"),
 ("Drill-down logic","Клик по KPI, точке графика или строке топ-отклонений открывает R-02 / R-03 с сохранением контекста фильтров; путь навигации отображается как drill-down path"),
 ("Editable fields","Нет (read-only). Executive summary-комментарий ведется в R-09 владельцами Head of HR Operations / Reward"),
 ("Comment logic","Плитка «Комментарии»: обязательные / open / escalated (демо: 42 / 18 / 3); переход в R-09 с фильтром по статусу"),
 ("Data quality rules","Индикатор DQ Status на top panel обязателен; при статусе Blocked форма показывает баннер «решения по данным не принимать»"),
 ("Access rights","R — Head of HR Operations, HRD, Head of Reward, Senior HRBP, Finance, HR Reporting; approve закрытия — Head of HR Operations (см. раздел 11)"),
 ("MVP scope","6 KPI cards; trend; waterfall (факторы YTD); Top-5 отклонений; 4 плитки статусов; доставка Excel + SSRS"),
 ("Future enhancements","R2: мобильный executive view; drill в BI self-service. R3: автогенерация narrative к отклонениям; предиктивный прогноз исполнения")])
h3("Пояснения по работе с формой")
p("Форма заменяет as-is дашборд COMP COST DASHBOARD и является точкой входа в ежемесячный цикл контроля. Принцип «причина рядом с суммой» реализован через waterfall факторов и колонку «Основной фактор» в таблице топ-отклонений. Статусные плитки — не декорация, а gate: amber/red по любой из плиток означает, что период нельзя закрывать без оговорок. АХР в KPI включен справочно; детальный разбор — на R-06.")
h3("Демо-пример: закрытие июня 2026")
cap("KPI cards (верхний ряд формы)")
table(["KPI","Значение","Отклонение / контекст"],
 [["Budget YTD, млн RUB","6 220.0","Budget Final v1.0"],
  ["Actual YTD, млн RUB","6 385.0","[red]▲ +165.0 (+2.7%) к Budget YTD"],
  ["Forecast FY, млн RUB","13 325.0","[red]▲ +380.0 (+2.9%) к Budget FY 12 945.0"],
  ["HC на 30.06.2026","988","[amber]▼ −23 к Plan 1 011"],
  ["MSU на 30.06.2026","971.3","[amber]▼ −31.2 к Plan 1 002.5"],
  ["АХР YTD, млн RUB","268.4","[red]▲ +28.4 (+11.8%) к Budget 240.0"]],
 w=[30,20,50])
cap("Top-5 отклонений и плитки статусов")
table(["Сегмент","Блок","Δ млн RUB","Δ %","Основной фактор","Comment Status"],
 [["xxx Bank / IT (TITM)","ФОТ","58.0","7.1","F03 Оклады + F02 незапланированные позиции","[red]Escalated"],
  ["xxx InvMan / Global Markets","ФОТ","33.0","6.6","F05 Премии — base effect","[amber]Under Review"],
  ["Subs / прочие","ФОТ","26.0","5.2","F07 Отпускные/резерв + F12 manual adj.","[amber]Needs Comment"],
  ["Recruitment Expenses (Группа)","АХР","24.5","28.8","АХР overspend / agency fees (R-06)","[green]Commented"],
  ["xxx Trust / Finance","ФОТ","13.0","5.2","F02 Незапланированная позиция + F10 charging","[green]Commented"]],
 w=[26,8,12,8,28,18])
table(["Плитка статуса","Значение (демо)"],
 [["Data Quality","[amber]Ready with Warnings — 10 warnings · 0 critical"],
  ["Reconciliation","[amber]+27.0 млн RUB (0.42%) · 4 open issues"],
  ["Комментарии","[amber]42 обязательных · 18 open · 3 escalated"],
  ["Closing Readiness","[amber]Ready with Warnings"]],
 w=[26,74])

# ---------------- R-02 ----------------
h2("6.2. R-02 Plan-Fact Explorer")
attr([
 ("Report name","Plan-Fact Explorer"),
 ("Report ID","R-02"),
 ("Уровень отчетности","Тактический — диалог с бизнесом, работа HRBP с периметром, материалы комитетов"),
 ("Purpose","Интерактивный анализ отклонений по всем разрезам: найти, где именно возникло отклонение, и понять, требует ли оно комментария"),
 ("Main users","Reward, Finance, HRBP, HR Operations"),
 ("Business questions","Где (LE / MIR / P&L / Budget Element) сосредоточено отклонение? Какое зерно дает основной вклад? Какие отклонения требуют обязательного комментария? Каков FY Outlook по выбранному срезу?"),
 ("Decisions supported","Постановка отклонения на комментирование; корректировка данных / маппингов; формирование запросов HRBP и Finance; выгрузка среза для комитета"),
 ("Frequency","Ежемесячно и on-demand в период закрытия"),
 ("Data sources","Budget DB, HRPT, Finance files, Variance service, Factor Engine, Comment store"),
 ("Grain","Month + Scenario + Version + Legal Entity + MIR-code + P&L Account + Budget Element; drill-down до Employee / Vacancy"),
 ("Filters","Year · Month · Scenario · Version · Legal Entity · MIR-code · Global Unit · HRBP perimeter · P&L Account · Budget Element · Comp / Non-comp · Factor Group · Comment Required"),
 ("Metrics","Budget · Forecast · HR Actual · Variance Amount · Variance % · FY Outlook · Comment Required flag · Comment Status"),
 ("Formulas","Variance Amount = Actual − Budget (по выбранному сценарию сравнения); Variance % = (Actual − Budget) / Budget; FY Outlook = Actual YTD + Σ Forecast(N+1..Dec)"),
 ("Visual layout","Top panel: фильтры. Ряд 1: KPI cards (Budget YTD, Actual YTD, Variance, Variance %, число отклонений с обязательным комментарием). Ряд 2: heatmap отклонений Budget Element × Legal Entity. Ряд 3: таблица детализации с variance bars и conditional formatting"),
 ("Drill-down logic","Month → Legal Entity → MIR-code → P&L Account → Budget Element → Employee / Vacancy; выбор ячейки heatmap фильтрует таблицу; drill-down path отображается строкой"),
 ("Editable fields","Нет в MVP (read-only анализ); корректировки данных выполняются в системах-источниках и бюджетной системе"),
 ("Comment logic","Колонка Comment Required (Да/Нет) по правилу >5% (ФОТ/АХР) и любое отклонение (HC/MSU); переход в R-09 по строке отклонения"),
 ("Data quality rules","Строки с DQ-дефектом (mapping, charging Σ≠100%, missing IDs) помечаются флагом Data Quality / Matching; такие строки не закрываются комментарием без устранения дефекта"),
 ("Access rights","R/W — Reward, Head of Reward; R — HRBP (свой периметр), Finance, HR Reporting; HRBP видит только свой HRBP perimeter"),
 ("MVP scope","Фильтры, KPI cards, heatmap, таблица детализации, variance bars, Comment Required, переход в R-09"),
 ("Future enhancements","R2: self-service BI (сохранение пользовательских срезов, закладки); R3: what-if симулятор изменений окладов / численности")])
h3("Пояснения по работе с формой")
p("Plan-Fact Explorer — рабочий инструмент аналитика: все 19 разрезов доступны как фильтры и оси, heatmap мгновенно показывает концентрацию отклонений, а признак Comment Required отделяет сигнал от шума. Форма развивает as-is отчет «План vs Факт»: добавляет сценарии, факторную колонку, связь с workflow комментариев и drill-down до первичного объекта.")
h3("Демо-пример: срез июнь 2026, Budget Final v1.0")
cap("Детализация (фрагмент таблицы формы)")
table(["Legal Entity","MIR-code","P&L Account","Budget Element","Budget YTD","Actual YTD","Variance","Var. %","Factor Group","Comment"],
 [["xxx Bank","TITM","4015100010~Salaries","Salary","812.4","846.1","[red]+33.7","4.1","F03 Оклады и ставка","Да"],
  ["xxx Bank","TITM","4015110010~Quarterly bonus","Quarterly Bonus","74.5","81.2","[red]+6.7","9.0","F05 Премии и variable pay","Да"],
  ["xxx InvMan","GMRE","4015100010~Salaries","Salary","118.2","129.6","[red]+11.4","9.6","F03 Оклады и ставка","Да"],
  ["xxx Capital","GBDM","4015100010~Salaries","Salary","96.8","97.1","+0.3","0.3","—","Нет"],
  ["xxx Trust","SFIN","4015100010~Salaries","Salary","44.1","47.9","[red]+3.8","8.6","F02 Незапланированная позиция","Да"],
  ["xxx Leasing","LND","4015100010~Salaries","Salary","51.2","53.0","+1.8","3.5","F01 Численность и сроки","Нет"],
  ["Subs / прочие","SCRM","4015300010~Other comp.","Other Compensation","9.5","15.6","[red]+6.1","64.2","F12 Прочее и one-off","Да"],
  ["xxx Bank","GCEO","4015200010~Benefits","Total Benefits","31.0","34.2","[red]+3.2","10.3","F09 Benefits","Да"]],
 w=[12,8,10,14,10,10,9,7,13,7], fs=8)
p("KPI cards формы на этом срезе: Budget YTD 6 220.0; Actual YTD 6 385.0; Variance [red]+165.0; Variance [red]+2.7%; «Отклонений с обязательным комментарием: 18». Heatmap «Budget Element × Legal Entity» показывает концентрацию: Salary × xxx Trust +15.0, Salary Uplift × xxx InvMan +11.9, Social Tax Salary × xxx Bank +17.4 (полная матрица — в Excel-альбоме, лист 03).")
