# content helpers
B = []  # global content blocks

def h1(t): B.append(("h1", t))
def h2(t): B.append(("h2", t))
def h3(t): B.append(("h3", t))
def p(t): B.append(("p", t))
def note(t): B.append(("note", t))
def cap(t): B.append(("caption", t))
def bullets(items): B.append(("bullets", items))
def numlist(items): B.append(("numlist", items))
def table(header, rows, w=None, fs=None): B.append(("table", {"header": header, "rows": rows, "w": w, "fs": fs}))
def pagebreak(): B.append(("pagebreak",))

def attr(rows):
    table(["Атрибут","Значение"], [[a, v] for a, v in rows], w=[20,80], fs=9)
