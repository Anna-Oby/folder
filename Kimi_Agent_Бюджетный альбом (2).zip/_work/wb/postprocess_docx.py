#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Post-process md2docx output: A4 page setup, footer with page numbers,
updateFields (TOC auto-update), core properties. Save to final path."""
import sys
import docx
from docx.shared import Mm, Pt, RGBColor
from docx.enum.text import WD_TAB_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

SRC = sys.argv[1] if len(sys.argv) > 1 else "/mnt/agents/output/_work/word_draft.footnote.docx"
DST = sys.argv[2] if len(sys.argv) > 2 else "/mnt/agents/output/Описание_отчетных_форм_бюджетной_системы.docx"

doc = docx.Document(SRC)
for s in doc.sections:
    s.page_width, s.page_height = Mm(210), Mm(297)
    s.left_margin = s.right_margin = Mm(20)
    s.top_margin, s.bottom_margin = Mm(19), Mm(19)
    s.footer_distance = Mm(10)

sec = doc.sections[0]
sec.footer.is_linked_to_previous = False
fp = sec.footer.paragraphs[0]
fp.text = ""
fp.paragraph_format.tab_stops.add_tab_stop(Mm(170), WD_TAB_ALIGNMENT.RIGHT)
r = fp.add_run("Описание отчетных форм бюджетной системы · v2.1 · июль 2026 · демо-данные\t")
r.font.size = Pt(8); r.font.color.rgb = RGBColor(0x7A, 0x82, 0x8E); r.font.name = "Calibri"
r2 = fp.add_run("стр. ")
r2.font.size = Pt(8); r2.font.color.rgb = RGBColor(0x7A, 0x82, 0x8E); r2.font.name = "Calibri"
fld = OxmlElement("w:fldSimple"); fld.set(qn("w:instr"), "PAGE")
rn = OxmlElement("w:r"); rpr = OxmlElement("w:rPr")
sz = OxmlElement("w:sz"); sz.set(qn("w:val"), "16"); rpr.append(sz)
col = OxmlElement("w:color"); col.set(qn("w:val"), "7A828E"); rpr.append(col)
rn.append(rpr)
t = OxmlElement("w:t"); t.text = "1"; rn.append(t); fld.append(rn)
fp._p.append(fld)

upd = OxmlElement("w:updateFields"); upd.set(qn("w:val"), "true")
doc.settings.element.insert(0, upd)

cp = doc.core_properties
cp.title = "Описание отчетных форм бюджетной системы"
cp.subject = "Альбом отчетных форм бюджетной системы по затратам на персонал · v2.1"
cp.author = "HR Analytics / BI"
cp.comments = "Демо-данные: закрытие июня 2026. Сопутствующий артефакт: Альбом_отчетных_форм_бюджетной_системы.xlsx"

doc.save(DST)
print("saved:", DST)
