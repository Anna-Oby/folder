#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Render content blocks (c00..c14) into word_draft.md for md2docx/pandoc.
All visual styling is emitted as raw openxml blocks (pandoc passes them through).
Palette (DESIGN_SPEC): NAVY 1F3864, BLUE_MED 2F5597, TEAL 17858C, GRAPHITE 3B3F46,
GRAY 7A828E, BG_LIGHT F5F7FA, BORDER C9D2DE; statuses RED C0392B / AMBER B7791F / GREEN 2E7D32.
"""
import re, os, html

WB = os.path.dirname(os.path.abspath(__file__))
OUT = "/mnt/agents/output/_work/word_draft.md"

NAVY, BLUE_MED, TEAL, GRAPHITE = "1F3864", "2F5597", "17858C", "3B3F46"
GRAY, BG_LIGHT, BORDER = "7A828E", "F5F7FA", "C9D2DE"
STATUS = {"red": "C0392B", "amber": "B7791F", "green": "2E7D32"}
PAGE_W = 9638  # usable width dxa: A4 11906 - 2x2cm(1134)

# ---------- load content modules ----------
ns = {}
for f in sorted(os.listdir(WB)):
    if re.fullmatch(r"c\d\d.*\.py", f):
        exec(compile(open(os.path.join(WB, f), encoding="utf8").read(), f, "exec"), ns)
B = ns["B"]

# ---------- helpers ----------
def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def parse_runs(text):
    """**bold** and [red]/[amber]/[green] color markers -> [(txt,bold,color)]"""
    out = []
    for i, part in enumerate(re.split(r"\*\*", text)):
        bold = (i % 2 == 1)
        color = None
        for j, seg in enumerate(re.split(r"\[(red|amber|green)\]", part)):
            if j % 2 == 1:
                color = STATUS[seg]
            elif seg:
                out.append((seg, bold, color))
    return out

def r_xml(txt, sz, bold=False, color=None, font="Calibri"):
    rpr = f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>'
    if bold: rpr += "<w:b/><w:bCs/>"
    if color: rpr += f'<w:color w:val="{color}"/>'
    rpr += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    return f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{esc(txt)}</w:t></w:r>'

def runs_xml(text, sz, base_bold=False, base_color=None, font="Calibri"):
    return "".join(r_xml(t, sz, base_bold or b, base_color or c, font)
                   for t, b, c in parse_runs(text))

def p_xml(runs, ppr=""):
    return f"<w:p><w:pPr>{ppr}</w:pPr>{runs}</w:p>"

def spacing(before=None, after=None, line=None):
    a = ""
    if before is not None or after is not None or line is not None:
        a = "<w:spacing"
        if before is not None: a += f' w:before="{before}"'
        if after is not None: a += f' w:after="{after}"'
        if line is not None: a += f' w:line="{line}" w:lineRule="auto"'
        a += "/>"
    return a

NUMRE = re.compile(r"^[\s\-\u2212+0-9.,%()·/▲▼—–]*$")

def is_numeric_col(rows, idx):
    vals = [r[idx] for r in rows if idx < len(r) and r[idx].strip() and r[idx].strip() != "—"]
    return bool(vals) and all(NUMRE.match(re.sub(r"\*\*|\[(red|amber|green)\]", "", v)) for v in vals)

def table_xml(spec):
    header, rows, w, fs = spec["header"], spec["rows"], spec.get("w"), spec.get("fs")
    fs = fs or 9.5
    hsz = int(round(fs * 2))
    ncol = len(header)
    if w:
        widths = [int(PAGE_W * x / 100) for x in w]
        widths[-1] += PAGE_W - sum(widths)
    else:
        widths = [PAGE_W // ncol] * ncol
        widths[-1] += PAGE_W - sum(widths)
    borders = (f'<w:tblBorders>' + "".join(
        f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="{BORDER}"/>'
        for s in ("top", "left", "bottom", "right", "insideH", "insideV")) + "</w:tblBorders>")
    tbl = ['<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:jc w:val="left"/>'
           '<w:tblLayout w:type="fixed"/>' + borders +
           '<w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="86" w:type="dxa"/>'
           '<w:bottom w:w="40" w:type="dxa"/><w:right w:w="86" w:type="dxa"/></w:tblCellMar>'
           '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>'
           "</w:tblPr><w:tblGrid>" + "".join(f'<w:gridCol w:w="{x}"/>' for x in widths) + "</w:tblGrid>"]
    aligns = ["right" if is_numeric_col(rows, i) else "left" for i in range(ncol)]
    def cell(text, dxa, hdr=False, shade=None, align="left"):
        tcpr = f'<w:tcW w:w="{dxa}" w:type="dxa"/>'
        if shade: tcpr += f'<w:shd w:val="clear" w:color="auto" w:fill="{shade}"/>'
        tcpr += f'<w:vAlign w:val="{"center" if hdr else "top"}"/>'
        ppr = spacing(after=0) + f'<w:jc w:val="{align}"/>'
        if hdr:
            runs = r_xml(text, hsz, bold=True, color="FFFFFF")
        else:
            runs = runs_xml(text, hsz)
        return f"<w:tc><w:tcPr>{tcpr}</w:tcPr>{p_xml(runs, ppr)}</w:tc>"
    # header
    tbl.append('<w:tr><w:trPr><w:tblHeader/><w:cantSplit/></w:trPr>' + "".join(
        cell(h, widths[i], hdr=True, shade=NAVY, align=aligns[i]) for i, h in enumerate(header)) + "</w:tr>")
    # body
    for ri, row in enumerate(rows):
        shade = BG_LIGHT if ri % 2 == 1 else None
        tds = []
        for i in range(ncol):
            txt = row[i] if i < len(row) else ""
            tds.append(cell(txt, widths[i], hdr=False, shade=shade, align=aligns[i]))
        tbl.append("<w:tr><w:trPr><w:cantSplit/></w:trPr>" + "".join(tds) + "</w:tr>")
    tbl.append("</w:tbl>")
    # keep-with-next caption spacing + small gap after table
    return "".join(tbl) + p_xml(r_xml("", 2), spacing(after=120))

# ---------- block renderers ----------
pending_break = {"v": False}

def h_xml(level, text):
    pb = '<w:pageBreakBefore/>' if pending_break["v"] else ""
    pending_break["v"] = False
    kn = "<w:keepNext/>"
    if level == 1:
        ppr = (f'<w:pStyle w:val="Heading1"/>{kn}{pb}{spacing(before=60, after=200)}'
               f'<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="4" w:color="8FAADC"/></w:pBdr>')
        return p_xml(runs_xml(text, 32, base_bold=True, base_color=NAVY, font="Calibri Light"), ppr)
    if level == 2:
        ppr = f'<w:pStyle w:val="Heading2"/>{kn}{pb}{spacing(before=280, after=100)}'
        return p_xml(runs_xml(text, 25, base_bold=True, base_color=BLUE_MED, font="Calibri Light"), ppr)
    ppr = f'<w:pStyle w:val="Heading3"/>{kn}{pb}{spacing(before=220, after=80)}'
    return p_xml(runs_xml(text, 22, base_bold=True, base_color=GRAPHITE), ppr)

def body_p(text):
    pb = '<w:pageBreakBefore/>' if pending_break["v"] else ""
    pending_break["v"] = False
    ppr = f'{pb}{spacing(after=140, line=276)}<w:jc w:val="both"/>'
    return p_xml(runs_xml(text, 21), ppr)

def note_p(text):
    pending_break["v"] = False
    ppr = (f'{spacing(before=120, after=160, line=260)}<w:ind w:left="180" w:right="180"/>'
           f'<w:pBdr><w:left w:val="single" w:sz="18" w:space="4" w:color="{NAVY}"/></w:pBdr>'
           f'<w:shd w:val="clear" w:color="auto" w:fill="{BG_LIGHT}"/>')
    runs = r_xml("Примечание. ", 19, bold=True, color=NAVY) + runs_xml(text, 19, base_color=GRAPHITE)
    return p_xml(runs, ppr)

def cap_p(text):
    pending_break["v"] = False
    ppr = f'<w:keepNext/>{spacing(before=200, after=60)}'
    return p_xml(runs_xml(text, 19, base_bold=True, base_color=GRAPHITE), ppr)

def bullet_ps(items):
    out = []
    for it in items:
        m = re.match(r"^(\s+)(.*)$", it, re.S)
        if m:  # sub-item with explicit numbering
            ppr = f'{spacing(after=60, line=260)}<w:ind w:left="640" w:hanging="0"/>'
            out.append(p_xml(runs_xml(m.group(2), 21, base_color=GRAPHITE), ppr))
        else:
            ppr = f'{spacing(after=60, line=260)}<w:ind w:left="340" w:hanging="200"/>'
            out.append(p_xml(r_xml("\u2022  ", 21, bold=True, color=TEAL) + runs_xml(it, 21), ppr))
    pending_break["v"] = False
    return "".join(out)

def numlist_ps(items):
    out = []
    for n, it in enumerate(items, 1):
        ppr = f'{spacing(after=70, line=260)}<w:ind w:left="400" w:hanging="280"/>'
        out.append(p_xml(r_xml(f"{n}.  ", 21, bold=True, color=BLUE_MED) + runs_xml(it, 21), ppr))
    pending_break["v"] = False
    return "".join(out)

# ---------- title page & TOC ----------
def title_page():
    x = []
    x.append(p_xml("", spacing(before=2200)))
    x.append(p_xml(r_xml("БЮДЖЕТНАЯ СИСТЕМА ПО ЗАТРАТАМ НА ПЕРСОНАЛ", 20, bold=True, color=TEAL),
                   spacing(before=0, after=60)))
    x.append(p_xml("", f'{spacing(after=400)}<w:pBdr><w:bottom w:val="single" w:sz="12" w:space="1" w:color="{TEAL}"/></w:pBdr>'))
    x.append(p_xml(r_xml("Описание отчетных форм", 60, bold=True, color=NAVY, font="Calibri Light"), spacing(after=0)))
    x.append(p_xml(r_xml("бюджетной системы", 60, bold=True, color=NAVY, font="Calibri Light"), spacing(after=200)))
    x.append(p_xml(r_xml("Альбом из 9 отчетных форм · budget control cockpit", 26, color=GRAPHITE), spacing(after=80)))
    x.append(p_xml(r_xml("Функциональное описание для обсуждения с бизнес-заказчиками и передачи в разработку", 21, color=GRAY), spacing(after=900)))
    info = [("Версия:", "2.1 · июль 2026"),
            ("Статус:", "для обсуждения с Head of HR Operations, HRD, Head of Reward, Finance"),
            ("Демо-контекст:", "отчетный год 2026 · закрыт период январь–июнь 2026 · сценарий Actual Jan–Jun + Forecast Jul–Dec vs Budget Final v1.0"),
            ("Факторная модель:", "12 пользовательских групп факторов (F01–F12) по корпоративному справочнику (79 из 142 применимых) · двухъярусный приоритет классификации (ярус 1 — 11 факторов справочника) · DQ — технический слой, не отображается"),
            ("Связанный артефакт:", "Альбом_отчетных_форм_бюджетной_системы.xlsx — 43 вкладки: 9 целевых форм, 6 спецификаций, 26 as-is форм · навигация гиперссылками"),
            ("Данные:", "демонстрационные (синтетические), взаимно согласованные; денежные суммы — млн RUB")]
    for i, (k, v) in enumerate(info):
        ppr = (f'{spacing(after=40, line=260)}<w:ind w:left="180" w:right="180"/>'
               f'<w:pBdr><w:left w:val="single" w:sz="18" w:space="4" w:color="{NAVY}"/></w:pBdr>'
               f'<w:shd w:val="clear" w:color="auto" w:fill="{BG_LIGHT}"/>')
        x.append(p_xml(r_xml(k + " ", 20, bold=True, color=NAVY) + r_xml(v, 20, color=GRAPHITE), ppr))
    x.append(p_xml("", spacing(after=500)))
    x.append(p_xml(r_xml("Пользователи: Head of HR Operations · HRD · Head of Reward · Senior HRBP · HRBP · Reward · Finance · HRIS · HR Reporting · Recruitment · LoD", 18, color=GRAY),
                   spacing(after=0)))
    return "".join(x)

def toc_page():
    x = []
    x.append(p_xml(r_xml("Оглавление", 32, bold=True, color=NAVY, font="Calibri Light"),
                   '<w:pageBreakBefore/>' + spacing(before=60, after=200) +
                   f'<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="4" w:color="8FAADC"/></w:pBdr>'))
    fld = ('<w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r>'
           '<w:r><w:instrText xml:space="preserve"> TOC \\o "1-2" \\h \\z \\u </w:instrText></w:r>'
           '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'
           + r_xml("Оглавление обновляется автоматически при открытии документа (или клавишей F9).", 21, color=GRAY) +
           '<w:r><w:fldChar w:fldCharType="end"/></w:r>')
    x.append(p_xml(fld, spacing(after=120)))
    return "".join(x)

# ---------- main ----------
raw_blocks = []
def emit(xml):
    raw_blocks.append("```{=openxml}\n" + xml + "\n```")

emit(title_page())
emit(toc_page())

for blk in B:
    kind = blk[0]
    if kind == "pagebreak":
        pending_break["v"] = True
    elif kind == "h1": emit(h_xml(1, blk[1]))
    elif kind == "h2": emit(h_xml(2, blk[1]))
    elif kind == "h3": emit(h_xml(3, blk[1]))
    elif kind == "p": emit(body_p(blk[1]))
    elif kind == "note": emit(note_p(blk[1]))
    elif kind == "caption": emit(cap_p(blk[1]))
    elif kind == "bullets": emit(bullet_ps(blk[1]))
    elif kind == "numlist": emit(numlist_ps(blk[1]))
    elif kind == "table": emit(table_xml(blk[1]))
    else: raise ValueError(f"unknown block {kind}")

md = "\n\n".join(raw_blocks) + "\n"
open(OUT, "w", encoding="utf8").write(md)
print(f"blocks={len(B)} raw_chunks={len(raw_blocks)} -> {OUT} ({len(md)} chars)")
h1s = [b[1] for b in B if b[0] == "h1"]
print("H1 sections:", len(h1s))
for t in h1s: print("  -", t)
h2s = [b[1] for b in B if b[0] == "h2"]
print("H2 count:", len(h2s), "| form cards:", len([t for t in h2s if re.match(r'6\.\d\.', t)]))
print("tables:", len([1 for b in B if b[0] == "table"]))
