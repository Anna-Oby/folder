# ---------------- R-05 ----------------
h2("6.5. R-05 Compensation Detail")
attr([
 ("Report name","Compensation Detail"),
 ("Report ID","R-05"),
 ("Уровень отчетности","Операционный — глубокая детализация, работа команд Reward / Finance / HR Operations"),
 ("Purpose","Дать детализацию ФОТ по 19 бюджетным элементам: состав, динамика по месяцам, отклонения по элементам, drill-down до сотрудника и назначения"),
 ("Main users","Reward, Finance, HR Operations"),
 ("Business questions","Из каких элементов складывается ФОТ и где концентрируются отклонения? Как элемент ведет себя по месяцам? Какие сотрудники / назначения формируют отклонение по элементу? Как связаны элементы между собой (база → бонус → соцвзносы → резерв)?"),
 ("Decisions supported","Подтверждение факторов salary / bonus / benefits / social security; корректировка ставок и коэффициентов в бюджетной модели; запросы Finance по проводкам; подготовка материалов Reward-комитета"),
 ("Frequency","Ежемесячно после закрытия; ежедневно в период закрытия"),
 ("Data sources","Budget DB (MG Compensation), HRPT (поименный HR-факт), Event Register, Comment store"),
 ("Grain","Month + Employee / Vacancy + Assignment + Legal Entity + MIR-code + Budget Element"),
 ("Filters","Year · Month · Scenario · Version · Legal Entity · MIR-code · Global Unit · HRBP perimeter · Budget Element · Comp / Non-comp · Factor Group"),
 ("Metrics","Budget / Forecast / Actual по каждому из 19 элементов · Variance Amount · Variance % · Actual by Month (Янв–Дек) · YTD Actual · Primary Factor · Comment Required · Comment Status"),
 ("Formulas","Quarterly Bonus = Salary Base × Bonus % (схема IT: 25% за квартал); Deferred Discretionary Bonus = 40% × Discretionary Bonus (список риск-тейкеров); Vacation Pay / Reserve = бонусная база года × 31/247/12 (капитальные LE); Social Tax = Taxable Base × Effective Rate (поименно, с порогами); Capitalized Compensation — со знаком минус"),
 ("Visual layout","Top panel: фильтры. Ряд 1: матрица «Budget Element × Month» (Actual) с колонками YTD Actual, Budget YTD, Variance, Variance % и conditional formatting. Ряд 2: trend по месяцам + bar chart Variance by Element. Ряд 3: drill-down таблица сотрудников / назначений со статусами комментариев"),
 ("Drill-down logic","Budget Element → Legal Entity → MIR-code → Employee / Assignment; из ячейки матрицы — в список сотрудников по элементу; переход в R-03 по фактору элемента"),
 ("Editable fields","Нет (read-only); ставки и коэффициенты модели редактируются в Budget DB владельцем версии"),
 ("Comment logic","Comment Required по правилу |Variance %| > 5% на уровне элемента × LE × MIR; владелец — Reward (salary / bonus / benefits), Finance (reserve / manual adj.)"),
 ("Data quality rules","Строки с дефектом charging history или mapping помечаются DQ-флагом; сумма элементов контрольно сходится к ФОТ (контрольная строка итога)"),
 ("Access rights","R/W — Reward, Head of Reward; R — Finance, HR Operations, Head of HR Operations, HR Reporting"),
 ("MVP scope","19 элементов; матрица элемент × месяц; trend; variance by element; drill-down до сотрудника; связь с комментариями"),
 ("Future enhancements","R2: поименный факт Benefits для всех LE; расширение бонусного движка (новые схемы); R3: what-if по ставкам и вилкам окладов")])
h3("Пояснения по работе с формой")
p("Форма покрывает полный перечень из 19 бюджетных элементов: Salary · Salary Uplift · Quarterly Bonus · Quarterly Bonus Uplift · Discretionary Bonus · Deferred Discretionary Bonus · Vacation Pay / Reserve · Social Tax Salary · Social Tax Salary Uplift · Social Tax Quarterly Bonus · Social Tax Quarterly Bonus Uplift · Social Tax Discretionary Bonus · Social Tax Deferred Discretionary Bonus · Social Tax Vacation Pay · Total Benefits · Other Compensation · Social Tax Other Compensation · Capitalized Compensation · Payments to Board Members. Элементы образуют расчетные цепочки: база (Salary, Uplift) → бонусы (% от базы) → соцвзносы (поименно с порогами) → резерв на отпуска (от бонусной базы). Поэтому отклонение по Salary каскадно объясняет отклонения связанных элементов — факторный движок (раздел 7) раскладывает эффект по цепочке без двойного счета. Форма развивает as-is отчеты Finance Report и Name by Name.")
h3("Демо-пример: ФОТ YTD январь–июнь 2026 по элементам")
cap("Бюджетные элементы: Budget / Actual / Variance YTD, млн RUB (сводка; полная матрица × месяцы — в Excel-альбоме, лист 06)")
table(["Budget Element","Budget YTD","Actual YTD","Variance","Var. %","Primary Factor","Comment"],
 [["Salary","3 929.3","3 960.3","+31.0","0.8","F01 / F03","Нет"],
  ["Salary Uplift","210.0","246.0","[red]+36.0","[red]17.1","F04 Индексация (E-2026-01)","Да"],
  ["Quarterly Bonus","372.0","391.0","[red]+19.0","[red]5.1","F05 — base effect","Да"],
  ["Quarterly Bonus Uplift","22.0","25.0","[red]+3.0","[red]13.6","F03 / F04","Да"],
  ["Discretionary Bonus","455.0","468.0","+13.0","2.9","F05 — accrual run-rate","Нет"],
  ["Deferred Discretionary Bonus","182.0","187.0","+5.0","2.7","F05 (linked 40%)","Нет"],
  ["Vacation Pay / Reserve","118.0","131.0","[red]+13.0","[red]11.0","F07 Резерв / средний заработок (E-2026-03)","Да"],
  ["Social Tax Salary","574.0","585.0","+11.0","1.9","F06 — base effect","Нет"],
  ["Social Tax Salary Uplift","31.5","37.0","[red]+5.5","[red]17.5","F06 — base effect","Да"],
  ["Social Tax Quarterly Bonus","56.0","59.0","[red]+3.0","[red]5.4","F06 — base effect","Да"],
  ["Social Tax Quarterly Bonus Uplift","3.3","3.8","[red]+0.5","[red]15.2","F06 — base effect","Да"],
  ["Social Tax Discretionary Bonus","68.5","70.5","+2.0","2.9","F06 — base effect","Нет"],
  ["Social Tax Deferred Disc. Bonus","27.5","28.5","+1.0","3.6","F06 — base effect","Нет"],
  ["Social Tax Vacation Pay","17.7","19.7","[red]+2.0","[red]11.3","F06 — base effect","Да"],
  ["Total Benefits","152.0","163.0","[red]+11.0","[red]7.2","F09 Benefits (тариф ДМС)","Да"],
  ["Other Compensation","48.0","61.0","[red]+13.0","[red]27.1","F12 one-off (E-2026-11)","Да"],
  ["Social Tax Other Compensation","7.2","9.2","[red]+2.0","[red]27.8","F06 — base effect","Да"],
  ["Payments to Board Members","26.0","26.0","0.0","0.0","—","Нет"],
  ["Capitalized Compensation","−80.0","−86.0","[green]−6.0","−7.5","F11 Капитализация (contra)","Нет"],
  ["**Итого ФОТ**","**6 220.0**","**6 385.0**","**[red]+165.0**","**+2.7**","—","11 обязательных"]],
 w=[26,11,11,10,8,26,8], fs=8)
p("Контроль сходимости: сумма по 19 элементам — Budget 6 220.0 / Actual 6 385.0 / Variance +165.0 (+2.7%) — равна ФОТ YTD на R-01 и входу waterfall на R-03. Динамика Actual по месяцам (Янв 998.0 · Фев 1 012.0 · Мар 1 118.0 · Апр 1 038.0 · Май 1 041.0 · Июн 1 178.0) показывает рост в июне за счет индексации и one-off выплаты.")
cap("Drill-down до сотрудника / назначения (фрагмент)")
table(["Person ID","Assignment","Legal Entity","MIR-code","Budget Element","Budget YTD","Actual YTD","Фактор / комментарий"],
 [["100287","ASG-2","xxx Bank","TITM","Salary","1.35","1.42","Early hire + salary above budget"],
  ["100287","ASG-2","xxx Bank","TITM","Social Tax Salary","0.41","0.43","—"],
  ["101512","ASG-1","xxx InvMan","GMRE","Salary","0.00","0.98","Unplanned hire"],
  ["101512","ASG-1","xxx InvMan","GMRE","Quarterly Bonus","0.00","0.24","Unplanned hire (bonus base)"],
  ["100130","ASG-1","xxx Capital","GCEO","Total Benefits","0.31","0.37","Benefits tariff change"],
  ["100996","ASG-3","xxx Trust","SFIN","Salary Uplift","0.06","0.09","Salary increase campaign"]],
 w=[9,10,11,9,17,10,10,24], fs=8)

# ---------------- R-06 ----------------
h2("6.6. R-06 АХР / Non-compensation Dashboard")
attr([
 ("Report name","АХР / Non-compensation Dashboard"),
 ("Report ID","R-06"),
 ("Уровень отчетности","Тактический — контроль категорий и владельцев, диалог с бизнесом"),
 ("Purpose","Контролировать некомпенсационные расходы на персонал (административно-хозяйственные расходы, связанные с персоналом) по категориям и владельцам"),
 ("Main users","HR Operations, Finance, LoD, Recruitment"),
 ("Business questions","Где перерасход / недоиспользование АХР? Какая категория и владелец формируют отклонение? Какие расходы не были запланированы? Что является разовым (one-off) и не повторится во втором полугодии?"),
 ("Decisions supported","Запрос комментариев владельцам категорий; перенос / отмена запланированных мероприятий; корректировка прогноза АХР до конца года; контроль подрядчиков"),
 ("Frequency","Ежемесячно после закрытия"),
 ("Data sources","Budget DB, Finance files (МСФО), HRPT (для связки с периметрами), Comment store"),
 ("Grain","Month + Legal Entity + MIR-code + P&L Account + АХР Category + Owner (если доступно)"),
 ("Filters","Year · Month · Scenario · Version · Legal Entity · MIR-code · АХР Category · Owner · Comp / Non-comp"),
 ("Metrics","АХР Budget YTD · АХР Actual YTD · АХР Variance · АХР Variance % · Variance by Category · подфактор · Owner · Comment Status · detail level indicator"),
 ("Formulas","АХР Variance = Actual АХР − Budget АХР (MVP); volume / rate декомпозиция не выполняется — нет стабильных драйверов (перенесена в R2)"),
 ("Visual layout","Top panel: фильтры. Ряд 1: 4 KPI cards. Ряд 2: bar chart Budget vs Actual по категориям + панель «MVP-логика». Ряд 3: таблица категорий с подфакторами, владельцами и статусами комментариев"),
 ("Drill-down logic","Категория → Legal Entity → MIR-code → P&L Account; до сотрудника drill-down не требуется (detail level: LE / MIR / P&L / Category / Owner)"),
 ("Editable fields","Нет (read-only)"),
 ("Comment logic","Comment Required при |Variance %| > 5% по категории × LE; владельцы: Recruitment Expenses → Recruitment / Finance; Staff Training / Seminars → LoD / Finance; Workshops / Offsites и Temporary Staff & Contractors → HR Operations / Finance"),
 ("Data quality rules","АХР сверяется с Finance-фактом на R-07 (расхождение YTD +2.6 млн RUB, 0.97%); незамапленные P&L accounts блокируют категорию до исправления"),
 ("Access rights","R/W — Finance, Recruitment (своя категория), LoD (своя категория); R — HR Operations, Head of HR Operations, HR Reporting"),
 ("MVP scope","4 категории АХР; KPI cards; bar chart; таблица с подфакторами и владельцами; detail level indicator; связь с R-09"),
 ("Future enhancements","R2: volume / rate декомпозиция (pilot на Recruitment Expenses — драйверы: число вакансий, agency fee); R3: бенчмаркинг стоимости найма")])
h3("Пояснения по работе с формой")
p("АХР трактуется как non-compensation expense: Recruitment Expenses · Staff Training / Seminars · Workshops / Offsites · Cost for Temporary Staff & Contractors. На текущий момент у АХР нет стабильных драйверов (объемные показатели не формализованы), поэтому в MVP декомпозиция ограничена формулой Actual − Budget и классификацией по подфакторам: АХР overspend · АХР underspend · unplanned АХР · planned АХР not spent · timing difference · one-off АХР · contractors variance · manual Finance adjustment. Volume / rate декомпозиция осознанно перенесена в релиз R2 — это зафиксировано в критериях приемки и в разделе 12.")
h3("Демо-пример: АХР YTD январь–июнь 2026")
cap("KPI cards: Budget 240.0 · Actual 268.4 · Variance [red]+28.4 (+11.8%) · Категорий с перерасходом: 3 из 4")
table(["АХР Category","Budget YTD","Actual YTD","Variance","Var. %","Подфактор","Owner","Comment Status"],
 [["Recruitment Expenses","85.0","109.5","[red]+24.5","[red]28.8","АХР overspend / unplanned АХР","Recruitment / Finance","[green]Commented"],
  ["Staff Training / Seminars","70.0","61.2","[green]−8.8","−12.6","Timing difference / planned not spent","LoD / Finance","[amber]Under Review"],
  ["Workshops / Offsites","45.0","52.9","[red]+7.9","[red]17.6","One-off АХР (kick-off Q2)","HR Operations / Finance","[green]Commented"],
  ["Temporary Staff & Contractors","40.0","44.8","[red]+4.8","[red]12.0","Contractors variance","HR Operations / Finance","[amber]Needs Comment"],
  ["**Итого АХР**","**240.0**","**268.4**","**[red]+28.4**","**+11.8**","—","—","—"]],
 w=[20,10,10,9,8,24,14,12], fs=8)
p("Интерпретация: перерасход Recruitment Expenses (+24.5, +28.8%) связан с внеплановыми агентскими комиссиями за закрытие критичных вакансий IT и Global Markets — комментарий получен, прогноз FY скорректирован. Недоиспользование Staff Training (−8.8) — перенос программ на Q3–Q4 (timing difference), статус Under Review у LoD. Динамика по месяцам: факт АХР вырос с 42.1 в январе до 49.0 в июне; прогноз декабря — 58.0 (годовые мероприятия).")
