# ---------------- R-03 ----------------
h2("6.3. R-03 Variance Waterfall / Factor Analysis")
attr([
 ("Report name","Variance Waterfall / Factor Analysis"),
 ("Report ID","R-03"),
 ("Уровень отчетности","Тактический — диалог с бизнесом о причинах отклонений, материалы комитетов"),
 ("Purpose","Показать, какие факторы сформировали отклонение: мост Budget → 12 факторных групп (F01–F12) + Residual → Actual с владельцами и статусами комментариев"),
 ("Main users","Head of HR Operations, Reward, Finance, HRBP"),
 ("Business questions","Из каких факторов складывается отклонение? Какой фактор основной (primary) по каждому рублю? Кто владелец и каков уровень автоматизации фактора? Что в residual и почему?"),
 ("Decisions supported","Согласование причин отклонений с владельцами; назначение комментариев; решения по зарегистрированным событиям; допуск residual к закрытию"),
 ("Frequency","Ежемесячно (обязательный артефакт закрытия); on-demand при смене версии / сценария"),
 ("Data sources","Factor Engine (HR-факт: HRPT + HR Tracker), Event Register, Comment store"),
 ("Grain","Factor Group (F01–F12) × Subfactor (FactorID корпоративного справочника) × Budget Element (с drill-down до Employee / Vacancy); период YTD или Month"),
 ("Filters","Year · Month / период · Scenario · Version · Legal Entity · MIR-code · Global Unit · Factor Group · Subfactor · Comment Status"),
 ("Metrics","Factor Effect (млн RUB) · вклад фактора в % от Variance · Owner · Уровень автоматизации (A5–A0) · Affected budget elements · Comment Status · Residual"),
 ("Formulas","По 12 группам факторов (F01–F12) — см. раздел 7: Timing Effect, Position Effect, Rate Effect, Indexation Effect (event), Bonus base/rate, Tax base + Threshold Effect, Average Earnings Effect, Severance Effect, Benefits, Allocation Effect, Capitalization Effect (contra), one-off; Residual = Total Variance − Σ Classified Factor Effects"),
 ("Visual layout","Top panel: фильтры. Слева: waterfall chart Budget → 12 факторных групп (F01–F12) + Residual → Actual (фактор DQ из диаграммы исключен — технический слой). Справа: панель «Как читать» (12 групп, двухъярусный приоритет — 21 шаг, DQ — технический слой). Ниже: таблица подфакторов с FactorID, уровнем автоматизации, owner и Comment Status; блок приоритета классификации (двухъярусный, 21 шаг; шаг 0 — DQ, технический, не отображается); статус residual"),
 ("Drill-down logic","Фактор → подфактор (FactorID) → Budget Element → Employee / Vacancy (HR-side); переход в R-05 для детализации по элементу"),
 ("Editable fields","Нет; классификация автоматическая по приоритету; ручная переклассификация — только через Event Register / комментарий в R-09 с аудитом"),
 ("Comment logic","Каждый подфактор несет Comment Status; подфакторы Needs Comment попадают в R-09 с назначенным владельцем"),
 ("Data quality rules","DQ — технический слой (F99): исключен из waterfall и всех пользовательских представлений, виден только на R-08 (раздел 7.8); residual сверх tolerance (±0.5% от Budget YTD) блокирует статус Ready to Close"),
 ("Access rights","R — Head of HR Operations, HRD, Finance, HRBP, HR Reporting; R/W (подтверждение факторов) — Reward, Head of Reward"),
 ("MVP scope","12 групп факторов (F01–F12; в MVP — факторы уровня A5/A4); waterfall без DQ; таблица 40 подфакторов; двухъярусный приоритет классификации (21 шаг); правила детекции R001–R010; residual с tolerance; связь с Event Register v1"),
 ("Future enhancements","Wave 2: event-driven факторы (F04, новые бонусные схемы, reorg bridge R009), F07 и F11 в полном объеме. Wave 3: suggested factors (A3), авто-классификация с подтверждением владельца; Run: автогенерация narrative")])
h3("Пояснения по работе с формой")
p("Waterfall строится на HR-факте; Finance-факт сюда не подмешивается — его роль в R-07. Состав факторов — 12 пользовательских групп (F01–F12) по факторной модели v2 (раздел 7.2); тринадцатый элемент модели, Data Quality / Matching (F99), является техническим слоем самопроверки и в waterfall не выводится (раздел 7.8). HC и MSU в waterfall не выводятся как самостоятельные факторы: они расчетные драйверы и диагностические показатели, а денежный эффект изменения численности раскладывается на реальные подфакторы групп F01 (сроки найма/ухода) и F02 (позиции, вакансии, замещение). Каждый рубль отклонения относится к одному primary factor по двухъярусному приоритету классификации (21 шаг) — это исключает двойной счет (пример anti-double-counting — в разделе 7.3).")
h3("Демо-пример: waterfall отклонения ФОТ YTD +165.0")
cap("Факторная декомпозиция Budget YTD 6 220.0 → Actual YTD 6 385.0, млн RUB (12 групп, без DQ)")
table(["Шаг waterfall","Эффект","Нарастающий итог","Комментарий"],
 [["Budget YTD","6 220.0","6 220.0","Budget Final v1.0"],
  ["F01 · Численность и сроки найма/ухода","−38.0","6 182.0","Отставание найма −48.0; найм раньше +18.0; увольнение раньше −14.0; увольнение позже +8.0; сдвиг найма −4.0; handover +2.0"],
  ["F02 · Позиции, вакансии и замещение","+41.0","6 223.0","Незапланированная позиция +46.0; отмененная позиция −11.0; on hold −4.0; другая роль/грейд +6.0; backfill +9.0/−5.0"],
  ["F03 · Оклады и ставка","+48.0","6 271.0","Rate variance +28.0; promotion +12.0; retention +4.0; grade mix +6.0/−2.0"],
  ["F04 · Индексация и политика оплаты","+28.0","6 299.0","Индексация выше бюджета (событие E-2026-01)"],
  ["F05 · Премии и variable pay","+38.0","6 337.0","База премии +26.0; accrual run-rate +4.0; разовая премия (E-2026-11) +8.0"],
  ["F06 · Налоги и взносы (вкл. порог)","+18.0","6 355.0","Эффект базы +20.0; предельная база раньше плана −2.0"],
  ["F07 · Отпускные и средний заработок","+15.0","6 370.0","Резерв +5.0; рост среднего заработка после годового бонуса (R006) +7.0; перерасчеты +3.0"],
  ["F08 · Severance и выплаты при увольнении","+9.0","6 379.0","Не бюджетируются; весь факт — отклонение"],
  ["F09 · Benefits","+10.0","6 389.0","ДМС +8.0; релокации +2.0"],
  ["F10 · Оргструктура и аллокации","−2.0","6 387.0","MSU ниже бюджета −1.5; salary charging −0.5; переводы net 0.0"],
  ["F11 · Капитализация ФОТ","−6.0","6 381.0","Рост капитализируемой доли (contra-эффект; база excl. отпускные)"],
  ["F12 · Прочее и one-off","+8.0","6 389.0","Ручная корректировка Finance +6.0; работа в выходные +2.0"],
  ["Residual / Needs Review","−4.0","6 385.0","В пределах tolerance ±31.1 (±0.5% от Budget YTD); статус Needs Comment"],
  ["Actual YTD","6 385.0","6 385.0","HR-факт янв–июн 2026"]],
 w=[24,10,14,52], fs=8.5)
p("Контроль сходимости: сумма факторных эффектов (−38.0 +41.0 +48.0 +28.0 +38.0 +18.0 +15.0 +9.0 +10.0 −2.0 −6.0 +8.0 −4.0) = +165.0 = Variance YTD; фактор Data Quality в waterfall отсутствует — это технический слой (раздел 7.8). Полная таблица из 40 подфакторов с FactorID, владельцами и статусами комментариев приведена в разделе 7.7.")

# ---------------- R-04 ----------------
h2("6.4. R-04 HC & Vacancy Bridge")
attr([
 ("Report name","HC & Vacancy Bridge"),
 ("Report ID","R-04"),
 ("Уровень отчетности","Тактический — работа HRBP с периметром, диалог с бизнесом о численности"),
 ("Purpose","Показать движение численности, вакансий и MSU и объяснить отклонение фактической численности от плана"),
 ("Main users","HRBP, Recruitment, Head of HR Operations"),
 ("Business questions","Почему Closing HC отличается от плана? Какие вакансии просрочены и где? Каков денежный эффект недозакрытия (связка с R-03)? Как меняется MSU?"),
 ("Decisions supported","Ускорение / пересмотр найма по просроченным вакансиям; решения по unplanned hires; корректировка HC-плана; постановка комментариев HC/MSU"),
 ("Frequency","Еженедельно (контроль) и ежемесячно (закрытие)"),
 ("Data sources","HR Tracker, Budget DB, HRPT (MSU, charging)"),
 ("Grain","Month × Employee / Vacancy × MIR-code × Legal Entity; агрегаты по HRBP perimeter и Global Unit"),
 ("Filters","Year · Month · Legal Entity · MIR-code · Global Unit · HRBP perimeter · Net status (Current / Hire / Leaver / Transfer / Maternity)"),
 ("Metrics","Opening HC · Hires · Leavers · Transfers In / Out · Vacancy Conversion · Closing HC · Plan HC · Δ HC vs Plan · MSU movement · открытые / просроченные вакансии · средний срок закрытия"),
 ("Formulas","Closing HC = Opening HC + Hires − Leavers + Transfers In − Transfers Out; Δ HC vs Plan = Closing HC − Plan HC; MSU movement — аналогичный мост в единицах MSU"),
 ("Visual layout","Top panel: фильтры + HRBP perimeter. Ряд 1: KPI cards (Opening HC, Hires, Leavers, Closing HC, Plan HC, MSU). Ряд 2: bridge chart. Ряд 3: таблица подфакторов Δ HC + панели «Вакансии» и «MSU movement». Низ: drill-down таблица сотрудников и вакансий с цветовыми статусами"),
 ("Drill-down logic","Подфактор (например, vacancy not filled) → список вакансий / сотрудников → карточка объекта (Vacancy ID, плановая дата, статус, owner)"),
 ("Editable fields","Плановые даты найма / увольнения и обоснования — только в HR Tracker (вне формы); форма read-only"),
 ("Comment logic","Любое отклонение HC / MSU — Comment Required = Да; владелец по умолчанию HRBP, по вакансиям — HRBP / Recruitment"),
 ("Data quality rules","Missing Vacancy ID / Employee ID и дубли блокируют подфактор до исправления (связь с R-08); декретницы считаются по правилам HC (список исключений)"),
 ("Access rights","R/W — HRBP (свой периметр), Recruitment (вакансии); R — Head of HR Operations, Reward, HR Reporting"),
 ("MVP scope","Bridge chart; подфакторы Δ HC (9 видов); панели вакансий и MSU; drill-down до сотрудника / вакансии"),
 ("Future enhancements","R2: прогноз закрытия вакансий (pipeline IRec / Experium); R3: what-if по плану найма")])
h3("Пояснения по работе с формой")
p("Форма развивает as-is summary HR Tracker (Summary_MIR/GD, Movement_* — в альбоме v2 сохранены без изменений как блок HCT; их целевая переработка выполняется отдельным этапом позже), добавляя две недостающие связи: отклонение численности → подфактор → первичный объект и отклонение численности → денежный эффект (через Factor Engine, группы F01 «Численность и сроки найма/ухода» и F02 «Позиции, вакансии и замещение» в R-03). Комментарий обязателен по любому отклонению HC / MSU — это правило отличает численностные метрики от денежных (порог 5%).")
h3("Демо-пример: полугодие 2026")
cap("HC bridge: 952 → 988 против плана 1 011")
table(["Шаг","Значение","Пояснение"],
 [["Opening HC (01.01.2026)","952","Стартовая численность периметров"],
  ["Hires","+80","В т.ч. early hire +12 и unplanned hire +9 к плану"],
  ["Leavers","−36","В т.ч. unplanned leaver −7 к плану"],
  ["Transfers In","+14","Переводы внутрь периметров"],
  ["Transfers Out","−22","Переводы за пределы периметров"],
  ["Closing HC (30.06.2026)","988","[amber]Δ к Plan 1 011: −23"]],
 w=[26,12,62])
cap("Отклонение HC от плана по подфакторам (Δ = −23) и панель вакансий")
table(["Подфактор","Δ HC vs Plan","Owner","Comment Status"],
 [["Delayed hire","−17","HRBP","[green]Commented"],
  ["Vacancy not filled","−23","Recruitment","[amber]Under Review"],
  ["Early hire","+12","HRBP","[green]Commented"],
  ["Unplanned hire","+9","HRBP","[red]Escalated"],
  ["Early leaver","+5","HRBP","[green]Commented"],
  ["Delayed leaver","−4","HRBP","Auto-classified"],
  ["Unplanned leaver","−7","HRBP","[green]Commented"],
  ["Maternity / replacement timing","+2","HRBP","Auto-classified"]],
 w=[30,12,20,22])
p("Панель вакансий: одобренные Vacancy_New — 64; Vacancy_Replacement — 25; всего открытых — 89; закрыто наймом в H1 — 71; просрочено против плановой даты — 23; средний срок закрытия — 54 дня. MSU movement: Opening MSU 944.6 → Hires +74.2 → Leavers −33.9 → Transfers (net) −5.1 → MSU / charging change −8.5 → Closing MSU 971.3 (план 1 002.5; Δ −31.2).")
