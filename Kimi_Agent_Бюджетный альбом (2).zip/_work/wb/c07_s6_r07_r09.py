# ---------------- R-07 ----------------
h2("6.7. R-07 HR vs Finance Reconciliation")
attr([
 ("Report name","HR vs Finance Reconciliation"),
 ("Report ID","R-07"),
 ("Уровень отчетности","Операционный — сверка и закрытие периода, работа команд Finance / Reward / HRIS"),
 ("Purpose","Сверить HR-факт и Finance-факт, классифицировать расхождения по типам и дать основание для закрытия периода"),
 ("Main users","Finance, Reward, HRIS, Head of HR Operations"),
 ("Business questions","Расходятся ли HR-факт и Finance-факт и насколько? Чем объясняется каждое расхождение? Какие расхождения — controlled exceptions (ожидаемые)? Что блокирует закрытие периода?"),
 ("Decisions supported","Допуск периода к закрытию; постановка issue владельцам (Finance / HRIS / Reward); принятие manual adjustments; подтверждение controlled exceptions"),
 ("Frequency","Ежемесячно (обязательный шаг закрытия); ежедневно в период закрытия после поступления Finance-файлов"),
 ("Data sources","HRPT (HR-факт), Finance files (МСФО), mapping tables (MIR → P&L, Budget Element → P&L Account, LE → Finance Legal), Comment store"),
 ("Grain","Month + Legal Entity + MIR-code + P&L Account + Budget Element; HR-side drill-down до Employee / Assignment, где доступно"),
 ("Filters","Year · Month · Legal Entity · MIR-code · P&L Account · Budget Element · Difference Type · Status · Controlled Exception"),
 ("Metrics","HR Actual · Finance Actual · Difference Amount · Difference % · Difference Type · Controlled Exception flag · Owner · Status · число open issues"),
 ("Formulas","Difference = Finance Actual − HR Actual; Difference % = (Finance − HR) / HR Actual; допуск к закрытию: |unclassified residual| < 0.05% от HR Actual"),
 ("Visual layout","Top panel: фильтры. Ряд 1: 5 KPI cards (HR Actual, Finance Actual, Difference, Open issues, Controlled exceptions). Ряд 2: reconciliation matrix (ФОТ / АХР / Итого) + bar chart по типам расхождений. Ряд 3: таблица типов расхождений с владельцами и статусами; панели controlled exceptions и closing status"),
 ("Drill-down logic","Блок (ФОТ / АХР) → Legal Entity → MIR-code → P&L Account → Budget Element → HR-side: Employee / Assignment (где HR-факт поименный)"),
 ("Editable fields","Статус issue и комментарий — Finance / Reward / HRIS по владению; подтверждение controlled exception — Finance"),
 ("Comment logic","Каждое open расхождение — issue с владельцем и SLA; unclassified residual всегда требует разбора до закрытия"),
 ("Data quality rules","Расхождения типа mapping difference и missing HR object автоматически создают DQ-задачи на R-08; сверка не выполняется до полной загрузки Finance-файлов"),
 ("Access rights","R/W — Finance (контролер), HRIS (mapping / missing objects); R — Reward, Head of HR Operations, HR Reporting; подтверждение закрытия — Head of HR Operations"),
 ("MVP scope","Reconciliation matrix; 10 типов расхождений; controlled exceptions; статус закрытия; связь с R-08 и R-09"),
 ("Future enhancements","R2: автоматическая классификация типов по правилам; интеграция с Hyperion (R3); поименная сверка Benefits")])
h3("Пояснения по работе с формой")
p("Finance-факт (МСФО) поступает позже HR-факта и служит независимым контрольным срезом: факторный анализ (R-03) намеренно строится на HR-факте, а R-07 отвечает на вопрос «можно ли закрывать период». Сверка выполняется в зерне Month × LE × MIR × P&L Account × Budget Element через mapping tables; расхождения классифицируются по 10 типам (раздел 8.3). Controlled exceptions — ожидаемые расхождения по категориям discretionary / deferred bonus, benefits, other compensation, capitalized compensation, recruitment, training, workshops / offsites — не блокируют закрытие, но ежемесячно подтверждаются Finance.")
h3("Демо-пример: сверка январь–июнь 2026")
cap("KPI cards: HR Actual YTD 6 385.0 · Finance Actual YTD 6 412.0 · Difference [amber]+27.0 (0.42%) · Open issues 4 · Controlled exceptions 3")
table(["Блок","HR Actual YTD","Finance Actual YTD","Difference","Difference %"],
 [["ФОТ","6 385.0","6 412.0","[amber]+27.0","0.42"],
  ["АХР","268.4","271.0","[amber]+2.6","0.97"],
  ["**Итого затраты на персонал**","**6 653.4**","**6 683.0**","**[amber]+29.6**","**0.44**"]],
 w=[30,18,18,14,12])
cap("Расхождения ФОТ по типам (млн RUB, Finance − HR)")
table(["Difference Type","Сумма","Описание","Owner","Status"],
 [["Timing difference","+10.0","Квартальный бонус: начисление в HR в месяц выплаты, в Finance — равномерно","Finance","[green]Resolved"],
  ["Accrual / reserve difference","+6.5","Vacation reserve: методика 31/247/12 vs фактическое начисление","Finance","Controlled exception"],
  ["Finance manual adjustment","+4.0","Ручная корректировка МСФО по Банку (март), подтверждена","Finance","Controlled exception"],
  ["Mapping difference","+1.5","3 новых MIR-code не замаплены на P&L (июльская реорганизация)","HRIS","[red]Open"],
  ["Granularity difference","+0.8","Benefits: HR поименно, Finance агрегатно по LE","Reward","Controlled exception"],
  ["Capitalization difference","+1.2","Capitalized compensation: расчетная оценка HR vs проводки Finance","Finance","[red]Open"],
  ["Missing HR object","+1.0","2 сотрудника Банка отсутствуют в HRPT (внешние совместители)","HRIS","[red]Open"],
  ["Unclassified residual","+2.0","Требует разбора до закрытия периода","Reward / Finance","[red]Open"],
  ["**Итого**","**+27.0**","Контроль: сходится к Difference по ФОТ","—","—"]],
 w=[20,9,41,13,14], fs=8)
p("Статус закрытия по сверке: [amber]Ready with Warnings. Условия: unclassified residual +2.0 (< 0.05% от HR Actual — в пределах допуска); 4 open issue со сроками SLA; расхождение по АХР (+2.6) отнесено к timing и будет разобрано с файлом Subs 03.07.")

# ---------------- R-08 ----------------
h2("6.8. R-08 Data Quality & Closing Readiness")
attr([
 ("Report name","Data Quality & Closing Readiness"),
 ("Report ID","R-08"),
 ("Уровень отчетности","Операционный — контроль качества данных (включая технический DQ-фактор) и закрытие периода"),
 ("Purpose","Определить, можно ли доверять данным и закрывать период: статус загрузок, дефекты данных (включая технический слой DQ / F99 факторной модели), SLA исправлений, итоговый статус готовности"),
 ("Main users","HRIS, HR Operations, Reward, Finance"),
 ("Business questions","Все ли источники загружены? Есть ли критические ошибки данных? Какие дефекты и у кого на исправлении? Соблюдается ли SLA? Можно ли закрывать период?"),
 ("Decisions supported","Блокировка / допуск закрытия периода; назначение исправлений владельцам; эскалация просроченных дефектов; исключение дефектных объектов из allocation-расчетов"),
 ("Frequency","Ежедневно в период закрытия; далее — еженедельный мониторинг"),
 ("Data sources","Load monitors (HRPT, HR Tracker, Finance files), DQ rules engine, mapping tables, Comment store"),
 ("Grain","Source System + Load Date + Period + Error Type + Owner"),
 ("Filters","Period · Source System · Error Type · Severity · Owner · Status"),
 ("Metrics","Статус загрузки HRPT / HR Tracker / Finance files · незамапленные MIR-code и P&L accounts · ошибки Legal Entity · ошибки salary / bonus charging (Σ≠100%) · missing Employee / Assignment / Vacancy ID · дубли · broken charging history · critical errors · warnings · SLA / aging · Closing Readiness"),
 ("Formulas","Closing Readiness = Ready to Close, если: critical errors = 0 ∧ recon residual в допуске ∧ покрытие обязательных комментариев ≥ 90%; Ready with Warnings — при warnings без critical; Blocked — при critical ≥ 1 или неполной загрузке; Under Investigation — при разборе инцидента"),
 ("Visual layout","Top panel: фильтры. Ряд 1: 4 статусные плитки (traffic light) с активным статусом + KPI (critical, warnings, SLA overdue). Ряд 2: таблица проверок с traffic-индикаторами, владельцами и SLA. Ряд 3: issue cards по владельцам"),
 ("Drill-down logic","Проверка → список дефектных объектов (Employee / Assignment / Vacancy / MIR-code / P&L Account) → карточка дефекта с историей"),
 ("Editable fields","Статус дефекта и комментарий исправления — владелец проверки; подтверждение исправления — HRIS"),
 ("Comment logic","Каждый warning / critical — задача с владельцем и SLA; просрочка SLA > 5 рабочих дней — эскалация Head of HR Operations (синхронно с R-09)"),
 ("Data quality rules","Это и есть форма правил качества: 13 стандартных проверок; объекты с salary charging Σ≠100% исключаются из allocation-факторов до исправления; broken charging history — приоритетный дефект (влияет на факторный анализ)"),
 ("Access rights","R/W — HRIS (все проверки), Reward (charging), Finance (P&L / файлы), Recruitment (Vacancy ID); R — Head of HR Operations, HR Reporting"),
 ("MVP scope","13 проверок; отображение технического DQ-фактора (F99) факторной модели — единственная форма, где он виден; traffic light dashboard; SLA-индикаторы; интеграция статуса в R-01 (DQ Status) и closing readiness service"),
 ("Future enhancements","R2: авто-fix для типовых дефектов charging; расширение правил (benefits, АХР); R3: профилирование данных и anomaly detection")])
h3("Пояснения по работе с формой")
p("Data Quality gate реализует принцип «DQ Status до решений»: статус качества данных дублируется на R-01 и R-02, а при статусе Blocked управленческие формы показывают предупреждение. Проверки сгруппированы по трем зонам: полнота загрузок (HRPT, HR Tracker, Finance files), целостность справочников и маппингов (MIR-code, P&L accounts, Legal Entity), корректность аллокаций (salary / bonus charging Σ=100%, история charging, missing IDs, дубли). Дефекты charging критичны именно для факторного анализа: без корректной истории charging эффект фактора F10 «Оргструктура и аллокации» считается недостоверным. R-08 — единственная форма, где отображается технический слой DQ (F99) факторной модели: суммы, объясненные подтвержденными дефектами данных, видны здесь до их исправления и перераспределения в содержательные факторы (раздел 7.8).")
h3("Демо-пример: статус периода июнь 2026 на 02.07.2026")
cap("Статус периода: [amber]Ready with Warnings · Critical errors 0 · Warnings 10 · Просрочено SLA 2")
table(["Проверка","Owner","Статус","Детали","Light","SLA / aging"],
 [["Загрузка HRPT (1С/ETL)","HRIS","OK","48 312 записей, расхождений 0","[green]●","—"],
  ["Синхронизация HR Tracker","HRIS","OK","HC/вакансии/движения за 01.07 учтены","[green]●","—"],
  ["Файлы Finance (МСФО)","Finance","Partial","Файл Банка загружен; файл Subs ожидается 03.07","[amber]●","1 день"],
  ["Незамапленные MIR-code","HRIS","Issue","3 новых кода июльской реорганизации","[amber]●","2 дня"],
  ["Незамапленные P&L accounts","Finance","OK","0","[green]●","—"],
  ["Ошибки Legal Entity","HRIS","OK","0","[green]●","—"],
  ["Ошибки salary charging (Σ≠100%)","Reward","Warning","2 сотрудника, auto-fix ожидает подтверждения","[amber]●","3 дня"],
  ["Ошибки bonus charging","Reward","OK","0","[green]●","—"],
  ["Missing Employee ID","HRIS","OK","0","[green]●","—"],
  ["Missing Assignment ID","HRIS","Warning","1 назначение (перевод 30.06)","[amber]●","1 день"],
  ["Missing Vacancy ID","Recruitment","OK","0","[green]●","—"],
  ["Дубли записей","HRIS","OK","0","[green]●","—"],
  ["Broken charging history","HRIS","Warning","4 сотрудника (разрывы истории charging)","[amber]●","[red]6 дней"]],
 w=[26,11,10,35,7,11], fs=8)
p("Итоговая оценка: критических ошибок нет; 10 warnings распределены между HRIS (6), Reward (2), Finance (2). Просроченный дефект — broken charging history (6 дней при SLA 5) — эскалирован; до исправления 4 сотрудника исключены из расчета фактора F10, а связанные суммы учтены в техническом слое DQ (F99) и не отображаются на пользовательских формах (раздел 7.8).")

# ---------------- R-09 ----------------
h2("6.9. R-09 Comments & Actions Tracker")
attr([
 ("Report name","Comments & Actions Tracker"),
 ("Report ID","R-09"),
 ("Уровень отчетности","Операционный — workflow закрытия периода, работа команд HRBP / Reward / Finance"),
 ("Purpose","Управлять комментариями к отклонениям: обязательность, владельцы, статусы, сроки, эскалация — единый workflow закрытия периода"),
 ("Main users","HRBP, Reward, Finance, HR Operations"),
 ("Business questions","Все ли обязательные отклонения прокомментированы? Какие комментарии просрочены и кто владелец? Что эскалировано и почему? Каково покрытие комментариев по периметру / роли?"),
 ("Decisions supported","Назначение / переназначение владельцев; эскалация просроченных; подтверждение (approve) комментариев; допуск периода к закрытию по критерию покрытия"),
 ("Frequency","Ежедневно в период закрытия"),
 ("Data sources","Variance service (обязательные отклонения), Comment store, Factor Engine (auto-classified), Event Register"),
 ("Grain","Variance × Owner × Status × Due date"),
 ("Filters","Period · Owner · Status · Comment Required (только обязательные) · Factor Group · Legal Entity · HRBP perimeter · Escalation flag"),
 ("Metrics","Всего обязательных комментариев · по статусам (New / Auto-classified / Needs Comment / Commented / Under Review / Confirmed / Escalated / Closed) · aging (рабочие дни) · due date · escalation flag · Comment Coverage %"),
 ("Formulas","Comment Required: ФОТ и АХР — |Variance %| > 5%; HC и MSU — любое отклонение. Comment Coverage = (Commented + Confirmed + Closed) / все обязательные. Эскалация: Needs Comment без реакции > 5 рабочих дней → Escalated + уведомление Head of HR Operations"),
 ("Visual layout","Top panel: фильтры + переключатель «только обязательные». Ряд 1: 5 KPI cards. Ряд 2: bar chart по статусам + панель правил обязательности и маршрутизации. Ряд 3: action list — таблица отклонений со status chips, владельцем, due date, aging, флагом эскалации"),
 ("Drill-down logic","Комментарий → карточка отклонения (сумма, фактор, история статусов) → переход в форму-источник (R-02 / R-03 / R-04 / R-06 / R-07) с сохранением контекста"),
 ("Editable fields","Текст комментария, статус, due date — владелец; подтверждение (Confirmed / Closed) — Head of Reward (ФОТ) и Head of HR Operations (итоговое); executive summary — Head of HR Operations / Reward"),
 ("Comment logic","Это и есть форма workflow: маршрутизация по правилам владения (8 правил, раздел 10.3); auto-classified отклонения не требуют ручного комментария, но доступны для ревью"),
 ("Data quality rules","Отклонение с активным DQ-дефектом не может быть закрыто комментарием до устранения дефекта (связь с R-08); комментарий к recon-расхождению создается как issue"),
 ("Access rights","R/W (comment) — все функциональные роли в своем владении / периметре; approve — Head of Reward, Head of HR Operations; R — HRD, HR Reporting"),
 ("MVP scope","8 статусов; правила обязательности; маршрутизация; SLA и эскалация; KPI покрытия; action list"),
 ("Future enhancements","R2: шаблоны комментариев и автоподстановка факторного объяснения; R3: автогенерация narrative и summary для комитета")])
h3("Пояснения по работе с формой")
p("Tracker закрывает главный процессный разрыв as-is: сбор комментариев по почте без статусов и сроков. Система сама вычисляет обязательность комментария (правило 5% для ФОТ / АХР; любое отклонение для HC / MSU), назначает владельца по правилам маршрутизации и ведет статусную модель до Closed. Все отклонения отображаются независимо от обязательности — фильтр «только обязательные» лишь фокусирует работу в период закрытия. Комментарий — часть аудита: текст, автор, история статусов и эскалации хранятся с отклонением.")
h3("Демо-пример: закрытие июня 2026")
cap("KPI cards: Всего обязательных 42 · Commented 24 · Under Review 8 · Needs Comment 7 · Escalated 3 · Покрытие 57% (цель ≥ 90% к 06.07)")
table(["ID","Отклонение","Δ сумма","Δ %","Обязателен","Owner","Status","Due date","Aging","Esc."],
 [["VAR-2026-0481","ФОТ · xxx InvMan · Salary Uplift · Июн","+12.4","18.2","Да (>5%)","Reward","[amber]Under Review","05.07.2026","2","Нет"],
  ["VAR-2026-0479","HC · Global Markets · Vacancy not filled","−23","—","Да (HC)","HRBP","[red]Escalated","03.07.2026","6","[red]Да"],
  ["VAR-2026-0475","АХР · Recruitment Expenses · YTD","+24.5","28.8","Да (>5%)","Recruitment / Finance","[green]Commented","04.07.2026","0","Нет"],
  ["VAR-2026-0468","ФОТ · xxx Bank · Other Compensation","+13.0","27.1","Да (>5%)","Finance","[green]Commented","04.07.2026","0","Нет"],
  ["VAR-2026-0462","MSU · xxx Capital · GTB","−4.2","—","Да (MSU)","HRBP","[amber]Needs Comment","06.07.2026","1","Нет"],
  ["VAR-2026-0455","ФОТ · Subs · Vacation Pay Reserve","+6.1","11.4","Да (>5%)","Finance","[amber]Needs Comment","06.07.2026","1","Нет"],
  ["VAR-2026-0451","HC · IT · Unplanned hire","+9","—","Да (HC)","HRBP","[red]Escalated","02.07.2026","8","[red]Да"],
  ["VAR-2026-0443","Recon · Mapping difference (MIR)","−1.5","—","Нет","HRIS","[red]Escalated","01.07.2026","9","[red]Да"]],
 w=[13,26,8,7,10,14,12,10,6,7], fs=8)
p("Три эскалации демонстрируют разные причины: VAR-2026-0479 — просрочка комментария HRBP > 5 рабочих дней; VAR-2026-0451 — спор о бизнес-обосновании unplanned hire (запрошено решение Head of HR Operations); VAR-2026-0443 — DQ-дефект маппинга, блокирующий закрытие комментария (связь с R-08).")
