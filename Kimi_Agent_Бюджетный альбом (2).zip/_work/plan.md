# План: Альбом отчетных форм бюджетной системы (затраты на персонал)

## Входные материалы (проанализированы)
- `/mnt/agents/upload/user_pasted_clipboard_long_content_as_file_Мастер-промпт для ра.txt` — мастер-ТЗ (9 форм, factor engine, 2 деливерабла, критерии приемки)
- `/mnt/agents/upload/Функциональные требования к бюджетной системе.docx` — методология (HC/MSU, charging, 19 бюджетных элементов, роли, UC)
- `/mnt/agents/upload/Budget forms_обезличено.xlsx` — 38 листов as-is (входные формы, отчеты, HC Tracker, загрузки факта, дашборды)

## Ключевые допущения (фиксируются в 00_README и в ответе пользователю)
1. Демо-данные синтетические, млн RUB, отчетный год 2026; закрытый период — янв–июнь 2026 (сценарий «в июле: факт янв–июнь + прогноз июл–дек vs Budget Final» — как в примере мастер-промпта).
2. Мокапы tool-agnostic: показывают целевой UX независимо от платформы (BI / SSRS / Excel).
3. Ядро альбома — 9 целевых форм из мастер-промпта; существующие формы as-is (Finance Report, Name by Name, SameStore, HC Tracker summaries, COMP COST DASHBOARD) регистрируются в 01_Report_Registry со статусом «as-is / заменяется / остается».
4. Все числа в демо-наборе взаимно согласованы (waterfall сходится к отклонению, LE сходятся к итогу, элементы — к ФОТ, bridge — к closing HC).

## Этап 1 — Дизайн-фундамент (Orchestrator, без скиллов)
- Сгенерировать согласованный демо-датасет: `/mnt/agents/output/_work/demo_data/*.csv` + `manifest.json`.
- Написать дизайн-спецификацию: `/mnt/agents/output/_work/DESIGN_SPEC.md` — визуальная система (цвета, типографика, KPI cards, badges, traffic lights), покадровый blueprint каждого из 17 листов Excel, структура Word-документа.

## Этап 2 — Параллельная сборка деливераблов
### 2A. Excel-альбом → субагент (coder), skill: `xlsx` (читать `/app/.agents/skills/xlsx/SKILL.md`)
Вход: DESIGN_SPEC.md + demo_data + мастер-промпт (путь).
Выход: `/mnt/agents/output/Альбом_отчетных_форм_бюджетной_системы.xlsx` — 17 листов:
00_README, 01_Report_Registry, 02_Budget_Control_Summary, 03_Plan_Fact_Explorer, 04_Variance_Waterfall,
05_HC_Vacancy_Bridge, 06_Compensation_Detail, 07_АХР_Dashboard, 08_Reconciliation, 09_Data_Quality,
10_Comments_Actions, 11_Metric_Dictionary, 12_Factor_Dictionary, 13_Field_Dictionary, 14_Access_Rights,
15_UAT_Cases, 16_Backlog_Roadmap.
Требования: нативные Excel-графики (waterfall через stacked bar с невидимой базой, trend line, bridge), heatmap через conditional formatting, KPI cards, скрытая сетка на дашбордах, обязательный recalc/verify после сборки.

### 2B. Word-документ → субагент (general), skills: `report-writing` (подход) + `docx` (сборка)
Вход: мастер-промпт, ФТ docx, demo_data, DESIGN_SPEC.md (разделы/решения).
Выход: `/mnt/agents/output/Описание_отчетных_форм_бюджетной_системы.docx` — 15 разделов по мастер-промпту,
карточки всех 9 форм (~20 атрибутов каждая), методология factor engine, reconciliation, DQ, workflow,
права доступа, MVP scope, roadmap, открытые вопросы, приложение с метриками и формулами. Язык — русский.

## Этап 3 — QA и итерация (Orchestrator + verifier при необходимости)
- Excel: проверить наличие 17 листов, наличие графиков на дашбордах, отсутствие #REF/ошибок, сходимость контрольных сумм с demo_data, визуальный spot-check (конвертация листов в изображения при необходимости).
- Word: документ открывается, стили/оглавление корректны, все 15 разделов и 9 карточек на месте, формулы без искажений.
- Фейл → уточнить инструкции и переделегировать.

## Этап 4 — Доставка
- Финальные файлы в `/mnt/agents/output/`, ответ пользователю с перечнем допущений и KIMI_REF тегами.
